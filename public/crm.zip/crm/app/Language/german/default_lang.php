<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* language locale */
$lang["language_locale"] = "de"; //locale code
$lang["language_locale_long"] = "de-DE"; //long locale code
$lang["text_direction"] = "ltr"; //supported value ltr/rtl

/* common */
$lang["add"] = "Hinzufügen";
$lang["edit"] = "Bearbeiten";
$lang["close"] = "Schließen";
$lang["cancel"] = "Abbrechen";
$lang["save"] = "Speichern";
$lang["delete"] = "Löschen";
$lang["description"] = "Beschreibung";
$lang["admin"] = "Admin";
$lang["manager"] = "Manager";
$lang["options"] = "Optionen";
$lang["id"] = "ID";
$lang["name"] = "Name";
$lang["email"] = "E-Mail";
$lang["username"] = "Benutzername";
$lang["password"] = "Passwort";
$lang["retype_password"] = "Passwort wiederholen";
$lang["previous"] = "Zurück";
$lang["next"] = "Weiter";
$lang["active"] = "Aktiv";
$lang["inactive"] = "Inaktiv";
$lang["status"] = "Status";
$lang["start_date"] = "Startdatum";
$lang["end_date"] = "Enddatum";
$lang["start_time"] = "Startzeit";
$lang["end_time"] = "Endzeit";
$lang["deadline"] = "Frist";
$lang["added"] = "Hinzugefügt";
$lang["created_date"] = "Erstellungsdatum";
$lang["created"] = "Erstellt";
$lang["created_by"] = "Erstellt von";
$lang["updated"] = "Aktualisiert";
$lang["deleted"] = "Gelöscht";
$lang["currency"] = "Währung";
$lang["new"] = "Neu";
$lang["open"] = "Offen";
$lang["closed"] = "Geschlossen";
$lang["date"] = "Datum";
$lang["yes"] = "Ja";
$lang["no"] = "Nein";
$lang["add_more"] = "Mehr hinzufügen";
$lang["crop"] = "Zuschneiden";
$lang["income"] = "Einnahmen";
$lang["income_vs_expenses"] = "Diagramm";

$lang["title"] = "Titel";
$lang["reset"] = "Zurücksetzen";
$lang["share_with"] = "Teilen mit";
$lang["company_name"] = "Firmenname";
$lang["address"] = "Adresse";
$lang["city"] = "Stadt";
$lang["state"] = "Bundesland";
$lang["zip"] = "PLZ";
$lang["country"] = "Land";
$lang["phone"] = "Telefon";
$lang["private"] = "Privat";
$lang["website"] = "Website";

$lang["sunday"] = "Sonntag";
$lang["monday"] = "Montag";
$lang["tuesday"] = "Dienstag";
$lang["wednesday"] = "Mittwoch";
$lang["thursday"] = "Donnerstag";
$lang["friday"] = "Freitag";
$lang["saturday"] = "Samstag";

$lang["daily"] = "Täglich";
$lang["monthly"] = "Monatlich";
$lang["weekly"] = "Wöchentlich";
$lang["yearly"] = "Jährlich";

$lang["see_all"] = "Alle ansehen";

/* messages */
$lang["error_occurred"] = "Sorry, ein Fehler trat bei dieser Aktion auf! <br /> Bitte versuche es später noch einmal.";
$lang["field_required"] = "Dieses Feld ist notwendig.";
$lang["end_date_must_be_equal_or_greater_than_start_date"] = "Das Enddatum muss gleich oder später sein, als das Startdatum.";
$lang["date_must_be_equal_or_greater_than_today"] = "Datum muss gleich oder später als heute sein.";
$lang["enter_valid_email"] = "Bitte gebe eine gültige E-Mail ein.";
$lang["enter_same_value"] = "Bitte gebe dasselbe nochmal ein.";
$lang["record_saved"] = "Der Eintrag wurde gespeichert.";
$lang["record_updated"] = "Der Eintrag wurde aktualisiert.";
$lang["record_cannot_be_deleted"] = "Der Eintrag ist in Verwendung und kann nicht gelöscht werden!";
$lang["record_deleted"] = "Der Eintrag wurde gelöscht.";
$lang["record_undone"] = "Der Eintrag wurde rückgängig gemacht.";
$lang["settings_updated"] = "Die Einstellungen wurden aktualisiert.";
$lang["enter_minimum_6_characters"] = "Bitte mindestens 6 Zeichen eingeben.";
$lang["message_sent"] = "Die Nachricht wurde gesendet.";
$lang["invalid_file_type"] = "Dateityp nicht erlaubt.";
$lang["something_went_wrong"] = "Uups, etwas ist schiefgelaufen!";
$lang["duplicate_email"] = "Die von Dir eingegebene E-Mail ist bereits registriert.";
$lang["comment_submited"] = "Der Kommentar wurde abgeschickt.";
$lang["no_new_messages"] = "Du hast keine neuen Nachrichten.";
$lang["sent_you_a_message"] = "Hat eine Nachricht gesendet";
$lang["max_file_size_3mb_message"] = "Die Dateigröße sollte 3MB nicht überschreiten.";
$lang["keep_it_blank_to_use_default"] = "Leerlassen für Standardeinstellung";
$lang["admin_user_has_all_power"] = "Administratoren haben vollen Zugriff auf dieses System!";
$lang["no_posts_to_show"] = "Keine verfügbaren Posts";

/* team_member */
$lang["add_team_member"] = "Team-Mitglied hinzufügen";
$lang["edit_team_member"] = "Mitglied bearbeiten ";
$lang["delete_team_member"] = "Mitglied entfernen";
$lang["team_member"] = "Mitglied";
$lang["team_members"] = "Mitglieder";
$lang["active_members"] = "Aktive Mitglieder";
$lang["inactive_members"] = "Inaktive Mitglieder";
$lang["first_name"] = "Vorname";
$lang["last_name"] = "Nachname";
$lang["mailing_address"] = "Postadresse";
$lang["alternative_address"] = "Alternative Adresse";
$lang["phone"] = "Telefon";
$lang["alternative_phone"] = "Alternative Telefonnummer";
$lang["gender"] = "Geschlecht";
$lang["male"] = "Männlich";
$lang["female"] = "Weiblich";
$lang["date_of_birth"] = "Geburtsdatum";
$lang["date_of_hire"] = "Einstellungsdatum";
$lang["ssn"] = "Sozialversichertennummer";
$lang["salary"] = "Gehalt";
$lang["salary_term"] = "Gehaltsklasse";
$lang["job_info"] = "Job-Info";
$lang["job_title"] = "Position/Funktion";
$lang["general_info"] = "Allgemeine Informationen";
$lang["account_settings"] = "Kontoeinstellungen";
$lang["list_view"] = "Listenansicht";
$lang["profile_image_changed"] = "Das Profilbild wurde erfolgreich geändert.";
$lang["send_invitation"] = "Einladung senden";
$lang["invitation_sent"] = "Die Einladung wurde gesendet.";
$lang["reset_info_send"] = "Erfolgreich gesendet!<br /><br />Bitte rufe die E-Mail auf, um den Prozess zu beenden.";
$lang["profile"] = "Profil";
$lang["my_profile"] = "Mein Profil";
$lang["change_password"] = "Passwort ändern";
$lang["social_links"] = "Social Links";
$lang["view_details"] = "Details anzeigen";
$lang["invite_someone_to_join_as_a_team_member"] = "Lade jemanden dazu ein, Team-Mitglied zu werden.";

/* team */
$lang["add_team"] = "Team hinzufügen";
$lang["edit_team"] = "Team bearbeiten";
$lang["delete_team"] = "Team löschen";
$lang["team"] = "Team(s)";
$lang["select_a_team"] = "Team wählen";

/* dashboard */
$lang["dashboard"] = "Dashboard";

/* attendance */
$lang["add_attendance"] = "Manuell Zeit hinzufügen";
$lang["edit_attendance"] = "Stundenzettel bearbeiten";
$lang["delete_attendance"] = "Stundenzettel löschen";
$lang["attendance"] = "Stundenzettel";
$lang["clock_in"] = "Einstempeln";
$lang["clock_out"] = "Ausstempeln";
$lang["in_date"] = "Startdatum";
$lang["out_date"] = "Enddatum";
$lang["in_time"] = "Startzeit";
$lang["out_time"] = "Endzeit";
$lang["clock_started_at"] = "Zeit gestartet um";
$lang["you_are_currently_clocked_out"] = "Derzeit ausgestempelt.";
$lang["members_clocked_in"] = "Eingestempelte Mitglieder";
$lang["members_clocked_out"] = "Ausgestempelte Mitglieder";
$lang["my_time_cards"] = "Meine Stundenzettel";
$lang["timecard_statistics"] = "Stundenzettel-Statistiken";
$lang["total_hours_worked"] = "Arbeitsstunden insgesamt";
$lang["total_project_hours"] = "Projektstunden insgesamt";

/* leave types */
$lang["add_leave_type"] = "Freistellungsart hinzufügen";
$lang["edit_leave_type"] = "Freistellungsart bearbeiten";
$lang["delete_leave_type"] = "Freistellungsart löschen";
$lang["leave_type"] = "Freistellungsart";
$lang["leave_types"] = "Freistellungen";

/* leave */
$lang["apply_leave"] = "Freistellung beantragen";
$lang["assign_leave"] = "Freistellung vergeben";
$lang["leaves"] = "Freistellungen";
$lang["pending_approval"] = "In Bearbeitung";
$lang["all_applications"] = "Alle Beantragungen";
$lang["duration"] = "Dauer";
$lang["single_day"] = "Ein Tag";
$lang["mulitple_days"] = "Mehrere Tage";
$lang["reason"] = "Grund";
$lang["applicant"] = "Von";
$lang["approved"] = "Genehmigt";
$lang["approve"] = "Genehmigen";
$lang["rejected"] = "Abgelehnt";
$lang["reject"] = "Ablehnen";
$lang["canceled"] = "Abgebrochen";
$lang["completed"] = "Beendet";
$lang["pending"] = "Schwebend (läuft)";
$lang["day"] = "Tage";
$lang["days"] = "Tage";
$lang["hour"] = "Stunde";
$lang["hours"] = "Stunden";
$lang["application_details"] = "Antragsdetails";
$lang["rejected_by"] = "Abgelehnt von";
$lang["approved_by"] = "Genehmigt von";
$lang["start_date_to_end_date_format"] = "%s bis %s";
$lang["my_leave"] = "Meine Freistellungen";

/* events */
$lang["add_event"] = "Termin hinzufügen";
$lang["edit_event"] = "Termin bearbeiten";
$lang["delete_event"] = "Termin löschen";
$lang["events"] = "Kalender";
$lang["event_calendar"] = "Kalender";
$lang["location"] = "Ort";
$lang["event_details"] = "Termin-Details";
$lang["event_deleted"] = "Der Termin wurde gelöscht.";
$lang["view_on_calendar"] = "Im Kalender ansehen";
$lang["no_event_found"] = "Keine Termine gefunden!";
$lang["events_today"] = "Heutige Termine";

/* announcement */
$lang["add_announcement"] = "Ankündigung hinzufügen";
$lang["edit_announcement"] = "Ankündigung bearbeiten";
$lang["delete_announcement"] = "Ankündigung löschen";
$lang["announcement"] = "Ankündigung";
$lang["announcements"] = "Ankündigungen";
$lang["all_team_members"] = "Alle Mitglieder";
$lang["all_team_clients"] = "Alle Kunden";

/* settings */
$lang["app_settings"] = "Einstellungen";
$lang["app_title"] = "Titel";
$lang["site_logo"] = "Logo";
$lang["invoice_logo"] = "Rechnungslogo";
$lang["timezone"] = "Zeitzone";
$lang["date_format"] = "Datenformat";
$lang["time_format"] = "Zeitformat";
$lang["first_day_of_week"] = "Erster Wochentag";
$lang["currency_symbol"] = "Währungssymbol";
$lang["general"] = "Allgemein";
$lang["general_settings"] = "Allgemeine Einstellungen";
$lang["item_purchase_code"] = "CodeCanyon-Lizenzcode";
$lang["company"] = "Unternehmen";
$lang["company_settings"] = "Einstellungen für das Unternehmen";
$lang["email_settings"] = "E-Mail-Einstellungen";
$lang["payment_methods"] = "Zahlungsmethoden";
$lang["email_sent_from_address"] = "E-Mail senden von (Adresse)";
$lang["email_sent_from_name"] = "E-Mail senden von (Name)";
$lang["email_use_smtp"] = "SMTP verwenden";
$lang["email_smtp_host"] = "SMTP Server";
$lang["email_smtp_user"] = "SMTP Benutzer";
$lang["email_smtp_password"] = "SMTP Passwort";
$lang["email_smtp_port"] = "SMTP Port";
$lang["send_test_mail_to"] = "Testmail senden an";
$lang["test_mail_sent"] = "Die Testmail wurde gesendet!";
$lang["test_mail_send_failed"] = "Senden der Testmail fehlgeschlagen.";
$lang["settings"] = "Einstellungen";
$lang["updates"] = "Aktualisierungen";
$lang["current_version"] = "Aktuelle Version";
$lang["language"] = "Sprache";
$lang["ip_restriction"] = "IP-Einschränkung";
$lang["varification_failed_message"] = "Sorry, wir konnten den Kaufcode nicht bestätigen.";
$lang["enter_one_ip_per_line"] = "Gebe eine IP pro Zeile an. Leerlassen um alle IPs zu erlauben. *Administratoren sind nicht betroffen.";
$lang["allow_timecard_access_from_these_ips_only"] = "Stundenzettel-Zugriff nur von diesen IPs erlauben.";
$lang["decimal_separator"] = "Dezimal-Indikator";
$lang["client_settings"] = "Kunden-Einstellungen";
$lang["disable_client_login_and_signup"] = "Kunden-Login und -Registrierung deaktivieren";
$lang["disable_client_login_help_message"] = "Ansprechpersonen der Kunden können sich nicht einloggen/registrieren, bis die Einstellung rückgängig gemacht wird.";
$lang["who_can_send_or_receive_message_to_or_from_clients"] = "Wer kann mit Kunden schreiben (Nachrichten)?";

/* account */
$lang["authentication_failed"] = "Authentifizierung fehlgeschlagen!";
$lang["signin"] = "Anmelden";
$lang["sign_out"] = "Abmelden";
$lang["you_dont_have_an_account"] = "Du hast noch kein Konto?";
$lang["already_have_an_account"] = "Du hast bereits ein Konto?";
$lang["forgot_password"] = "Passwort vergessen?";
$lang["signup"] = "Registrieren.";
$lang["input_email_to_reset_password"] = "E-Mail eingeben, um Ihr Passwort zurückzusetzen.";
$lang["no_acount_found_with_this_email"] = "Sorry, es wurde kein Konto mit dieser E-Mail gefunden.";
$lang["reset_password"] = "Passwort zurücksetzen";
$lang["password_reset_successfully"] = "Ihr Passwort wurde erfolgreich zurückgesetzt.";
$lang["account_created"] = "Ihr Konto wurde erfolgreich erstellt!";
$lang["invitation_expaired_message"] = "Die Einladung ist abgelaufen oder etwas lief schief";
$lang["account_already_exists_for_your_mail"] = "Es besteht bereits ein Konto mit dieser E-Mail";
$lang["create_an_account_as_a_new_client"] = "Konto als Kunde erstellen.";
$lang["create_an_account_as_a_team_member"] = "Konto als Team-Mitglied erstellen.";
$lang["create_an_account_as_a_client_contact"] = "Konto als Kunden-Ansprechpartner erstellen.";

/* messages */
$lang["messages"] = "Nachrichten";
$lang["message"] = "Nachricht";
$lang["compose"] = "Verfassen";
$lang["send_message"] = "Nachricht senden";
$lang["write_a_message"] = "Nachricht schreiben...";
$lang["reply_to_sender"] = "Antworten...";
$lang["subject"] = "Betreff";
$lang["send"] = "Senden";
$lang["to"] = "An";
$lang["from"] = "Von";
$lang["inbox"] = "Posteingang";
$lang["sent_items"] = "Gesendete";
$lang["me"] = "Ich";
$lang["select_a_message"] = "<br>Zu betrachtende Nachricht auswählen";

/* clients */
$lang["add_client"] = "Kunde hinzufügen";
$lang["edit_client"] = "Kunde bearbeiten";
$lang["delete_client"] = "Kunde löschen";
$lang["client"] = "Kunde";
$lang["clients"] = "Kunden";
$lang["client_details"] = "Kunden-Details";
$lang["due"] = "Fällig";

$lang["add_contact"] = "Ansprechpartner hinzufügen";
$lang["edit_contact"] = "Ansprechpartner bearbeiten";
$lang["delete_contact"] = "Ansprechpartner löschen";
$lang["contact"] = "Ansprechpartner";
$lang["contacts"] = "Ansprechpartner";
$lang["users"] = "Benutzer";
$lang["primary_contact"] = "Primärer Ansprechpartner";
$lang["disable_login"] = "Login deaktivieren";
$lang["disable_login_help_message"] = "Der Benutzer wird sich nicht ins System einloggen können!";
$lang["email_login_details"] = "Anmeldedaten an diesen Nutzer mailen";
$lang["generate"] = "Generieren";
$lang["show_text"] = "Text zeigen";
$lang["hide_text"] = "Text verbergen";
$lang["mark_as_inactive"] = "Als inaktiv kennzeichnen";
$lang["mark_as_inactive_help_message"] = "Inaktive Benutzer können sich nicht anmelden und werden bei den aktiven Benutzern nicht mit aufgezählt!";

$lang["invoice_id"] = "Rechnungsnummer";
$lang["payments"] = "Zahlungen";
$lang["invoice_sent_message"] = "Die Rechnung wurde gesendet!";
$lang["attached"] = "Angehängt";
$lang["vat_number"] = "Steuernummer";
$lang["invite_an_user"] = "Einen Nutzer zu %s einladen"; // Invite an user for {company name}
$lang["unit_type"] = "Einheit";

/* projects */
$lang["add_project"] = "Projekt hinzufügen";
$lang["edit_project"] = "Projekt bearbeiten";
$lang["delete_project"] = "Projekt löschen";
$lang["project"] = "Projekt";
$lang["projects"] = "Projekte";
$lang["all_projects"] = "Alle Projekte";
$lang["member"] = "Mitglied";
$lang["overview"] = "Überblick";
$lang["project_members"] = "Projektmitglieder";
$lang["add_member"] = "Mitglied hinzufügen";
$lang["delete_member"] = "Mitglied entfernen";
$lang["start_timer"] = "Timer starten";
$lang["stop_timer"] = "Timer stoppen";
$lang["project_timeline"] = "Projekt-Chronik";
$lang["open_projects"] = "Offene Projekte";
$lang["projects_completed"] = "Beendete Projekte";
$lang["progress"] = "Fortschritt";
$lang["activity"] = "Aktivität";
$lang["started_at"] = "Begonnen am";
$lang["customer_feedback"] = "Kundenkommentare";
$lang["project_comment_reply"] = "Antwort Projekt-Kommentar";
$lang["task_comment_reply"] = "Antwort Aufgaben-Kommentar";
$lang["file_comment_reply"] = "Antwort Datei-Kommentar";
$lang["customer_feedback_reply"] = "Antwort Kundenkommentar";

/* expense */
$lang["add_category"] = "Kategorie hinzufügen";
$lang["edit_category"] = "Kategorie bearbeiten";
$lang["delete_category"] = "Kategorie löschen";
$lang["category"] = "Kategorie";
$lang["categories"] = "Kategorien";
$lang["expense_categories"] = "Ausgaben";
$lang["add_expense"] = "Ausgabe hinzufügen";
$lang["edit_expense"] = "Ausgabe bearbeiten";
$lang["delete_expense"] = "Ausgabe löschen";
$lang["expense"] = "Ausgabe";
$lang["expenses"] = "Ausgaben";
$lang["date_of_expense"] = "Datum der Ausgabe";
$lang["finance"] = "Finanzen";

/* notes */
$lang["add_note"] = "Notiz hinzufügen";
$lang["edit_note"] = "Notiz bearbeiten";
$lang["delete_note"] = "Notiz löschen";
$lang["note"] = "Notiz";
$lang["notes"] = "Notizen";
$lang["sticky_note"] = "Haftnotiz (Privat)";

/* history */
$lang["history"] = "Geschichte";

/* timesheet */
$lang["timesheets"] = "Stundenzettel";
$lang["log_time"] = "Zeit aufnehmen";
$lang["edit_timelog"] = "Zeitaufnahme bearbeiten";
$lang["delete_timelog"] = "Zeitaufnahme löschen";
$lang["timesheet_statistics"] = "Stundenzettel-Statistiken";

/* milestones */
$lang["add_milestone"] = "Meilenstein hinzufügen";
$lang["edit_milestone"] = "Meilenstein bearbeiten";
$lang["delete_milestone"] = "Meilenstein löschen";
$lang["milestone"] = "Meilenstein";
$lang["milestones"] = "Meilensteine";

/* files */
$lang["add_files"] = "Dateien hinzufügen";
$lang["edit_file"] = "Datei bearbeiten";
$lang["delete_file"] = "Datei löschen";
$lang["file"] = "Datei";
$lang["files"] = "Dateien";
$lang["file_name"] = "Dateiname";
$lang["size"] = "Größe";
$lang["uploaded_by"] = "Hochgeladen von";
$lang["accepted_file_format"] = "Akzeptiertes Dateiformat";
$lang["comma_separated"] = "Kommagetrennt";
$lang["project_file"] = "Projektdatei";
$lang["download"] = "Download";
$lang["download_files"] = "%s Dateien herunterladen"; //Ex. Download 4 files
$lang["file_preview_is_not_available"] = "Keine Dateivorschau verfügbar.";

/* tasks */
$lang["add_task"] = "Aufgabe hinzufügen";
$lang["edit_task"] = "Aufgabe bearbeiten";
$lang["delete_task"] = "Aufgabe löschen";
$lang["task"] = "Aufgabe";
$lang["tasks"] = "Aufgaben";
$lang["my_tasks"] = "Meine Aufgaben";
$lang["my_open_tasks"] = "Meine offenen Aufgaben";
$lang["assign_to"] = "Zuordnen zu";
$lang["assigned_to"] = "Zugeordnet zu";
$lang["labels"] = "Labels";
$lang["to_do"] = "Ausstehend";
$lang["in_progress"] = "In Bearbeitung";
$lang["done"] = "Fertig";
$lang["task_info"] = "Aufgabeninfo";
$lang["points"] = "Punkte";
$lang["point"] = "Punkt";
$lang["task_status"] = "Aufgabenstatus";

/* comments */
$lang["comment"] = "Kommentar";
$lang["comments"] = "Kommentare";
$lang["write_a_comment"] = "Einen Kommentar schreiben...";
$lang["write_a_reply"] = "Eine Antwort schreiben...";
$lang["post_comment"] = "Kommentar posten";
$lang["post_reply"] = "Antwort posten";
$lang["reply"] = "antworten";
$lang["replies"] = "Antworten";
$lang["like"] = "Like";
$lang["unlike"] = "Dislike";
$lang["view"] = "Ansehen";
$lang["project_comment"] = "Projekt-Kommentar";
$lang["task_comment"] = "Aufgaben-Kommentar";
$lang["file_comment"] = "Datei-Kommentar";

/* time format */
$lang["today"] = "Heute";
$lang["yesterday"] = "Gestern";
$lang["tomorrow"] = "Morgen";

$lang["today_at"] = "Heute um";
$lang["yesterday_at"] = "Gestern um";

/* tickets */

$lang["add_ticket"] = "Ticket hinzufügen";
$lang["ticket"] = "Ticket";
$lang["tickets"] = "Tickets";
$lang["ticket_id"] = "Ticket-ID";
$lang["client_replied"] = "Kunde hat geantwortet";
$lang["change_status"] = "Status ändern";
$lang["last_activity"] = "Letzte Aktivität";
$lang["open_tickets"] = "Offene Tickets";
$lang["ticket_status"] = "Ticket-Status";

/* ticket types */

$lang["add_ticket_type"] = "Ticket-Typ hinzufügen";
$lang["ticket_type"] = "Ticket-Typ";
$lang["ticket_types"] = "Ticket-Typen";
$lang["edit_ticket_type"] = "Ticket-Typ bearbeiten";
$lang["delete_ticket_type"] = "Ticket-Typ löschen";

/* payment methods */

$lang["add_payment_method"] = "Zahlungsart hinzufügen";
$lang["payment_method"] = "Zahlungsart";
$lang["payment_methods"] = "Zahlungsarten";
$lang["edit_payment_method"] = "Zahlungsart bearbeiten";
$lang["delete_payment_method"] = "Zahlungsart löschen";

/* invoices */

$lang["add_invoice"] = "Rechnung hinzufügen";
$lang["edit_invoice"] = "Rechnung bearbeiten";
$lang["delete_invoice"] = "Rechnung löschen";
$lang["invoice"] = "Rechnung";
$lang["invoices"] = "Rechnungen";
$lang["bill_date"] = "Rechnungsdatum";
$lang["due_date"] = "Fälligkeitsdatum";
$lang["payment_date"] = "Zahlungsdatum";
$lang["bill_to"] = "Rechnung an";
$lang["invoice_value"] = "Betrag";
$lang["payment_received"] = "Erhaltene Zahlungen";
$lang["invoice_payments"] = "Einnahmen";
$lang["draft"] = "Entwurf";
$lang["fully_paid"] = "Vollständig bezahlt";
$lang["partially_paid"] = "Teilweise bezahlt";
$lang["not_paid"] = "Nicht gezahlt";
$lang["overdue"] = "Überfällig";
$lang["invoice_items"] = "Rechnungsposten";
$lang["edit_invoice"] = "Rechnung bearbeiten";
$lang["delete_invoice"] = "Rechnung löschen";
$lang["item"] = "Posten";
$lang["add_item"] = "Posten hinzufügen";
$lang["create_new_item"] = "Posten erstellen";
$lang["select_or_create_new_item"] = "Posten aus der Liste wählen oder neu erstellen...";
$lang["quantity"] = "Anzahl";
$lang["rate"] = "Rate";
$lang["total_of_all_pages"] = "Summe aller Seiten";
$lang["sub_total"] = "Zwischensumme";
$lang["total"] = "Gesamtbetrag";
$lang["last_email_sent"] = "Letzte E-Mail gesendet";
$lang["item_library"] = "Gespeicherte Posten";
$lang["add_payment"] = "Zahlung hinzufügen";
$lang["never"] = "Nie";
$lang["email_invoice_to_client"] = "Rechnung an Kunde senden";
$lang["download_pdf"] = "PDF herunterladen";
$lang["print"] = "Drucken";
$lang["actions"] = "Aktionen";
$lang["balance_due"] = "Endbetrag";
$lang["paid"] = "Bezahlt";
$lang["amount"] = "Betrag";
$lang["invoice_payment_list"] = "Rechnungszahlungen (Liste)";
$lang["invoice_statistics"] = "Rechnungs-Statistiken";
$lang["payment"] = "Zahlung";

/* email templates */
$lang["email_templates"] = "E-Mail-Vorlagen";
$lang["select_a_template"] = "Zu bearbeitende Vorlage auswählen";
$lang["avilable_variables"] = "Verfügbare Variablen";
$lang["restore_to_default"] = "Auf Standard zurücksetzen";
$lang["template_restored"] = "Die Vorlage wurde zurückgesetzt.";
$lang["login_info"] = "Logindaten";
$lang["reset_password"] = "Passwort zurücksetzen";
$lang["team_member_invitation"] = "Einladung zum Projektmanager";
$lang["client_contact_invitation"] = "Einladung für Ihr Kundenkonto";
$lang["send_invoice"] = "Rechnung senden";
$lang["signature"] = "Signatur";

/* roles */

$lang["role"] = "Benutzergruppe";
$lang["roles"] = "Benutzergruppen";
$lang["add_role"] = "Benutzergruppe hinzufügen";
$lang["edit_role"] = "Benutzergruppe bearbeiten";
$lang["delete_role"] = "Benutzergruppe löschen";
$lang["use_seetings_from"] = "Benutze Einstellungen von";
$lang["permissions"] = "Rechte";
$lang["yes_all_members"] = "Ja, alle Mitglieder";
$lang["yes_specific_members_or_teams"] = "Ja, die bestimmter Mitglieder oder Teams";
$lang["yes_specific_ticket_types"] = "Ja, bestimmte Ticket-Typen";
$lang["select_a_role"] = "Gruppe auswählen";
$lang["choose_members_and_or_teams"] = "Mitglieder und / oder Teams auswählen";
$lang["choose_ticket_types"] = "Ticket-Typen auswählen";
$lang["excluding_his_her_time_cards"] = "eigene ausgeschlossen";
$lang["excluding_his_her_leaves"] = "eigene ausgeschlossen";
$lang["can_manage_team_members_leave"] = "Kann Freistellungen verwalten:";
$lang["can_manage_team_members_timecards"] = "Kann Stundenzettel verwalten:";
$lang["can_access_invoices"] = "Kann Rechnungen verwalten:";
$lang["can_access_expenses"] = "Kann Ausgaben verwalten:";
$lang["can_access_clients_information"] = "Kann Kundeninformationen einsehen:";
$lang["can_access_tickets"] = "Kann auf Tickets zugreifen:";
$lang["can_manage_announcements"] = "Kann Ankündigungen verwalten:";

/* timeline */
$lang["post_placeholder_text"] = "Teile eine Idee, einen Gedanken oder Datei...";
$lang["post"] = "Posten";
$lang["timeline"] = "Chronik";
$lang["load_more"] = "Mehr laden";
$lang["upload_file"] = "Datei hochladen";
$lang["upload"] = "Upload";
$lang["new_posts"] = "Neue Posts";

/* taxes */

$lang["add_tax"] = "Steuer hinzufügen";
$lang["tax"] = "Steuer";
$lang["taxes"] = "Steuern";
$lang["edit_tax"] = "Steuer bearbeiten";
$lang["delete_tax"] = "Steuer löschen";
$lang["percentage"] = "Anteil (%)";
$lang["second_tax"] = "Zweitsteuer";

/* Version 1.2 */
$lang["available_on_invoice"] = "Verfügbar bei Rechnungen";
$lang["available_on_invoice_help_text"] = "Die Zahlungsart ist in der Rechnung des Kunden sichtbar.";
$lang["minimum_payment_amount"] = "Minimalbetrag für Zahlungen";
$lang["minimum_payment_amount_help_text"] = "Kunden wird es nicht möglich sein mit dieser Zahlungsart zu zahlen, wenn der Rechnungsbetrag geringer als dieser ist.";
$lang["pay_invoice"] = "Rechnung zahlen";
$lang["pay_button_text"] = "Zahlbutton-Text";
$lang["minimum_payment_validation_message"] = "Der Zahlungsbetrag kann nicht geringer sein als: "; //ex. The payment amount can't be less then: USD 100.00
$lang["invoice_settings"] = "Rechnungseinstellungen";
$lang["allow_partial_invoice_payment_from_clients"] = "Teilweise Zahlungen erlauben";
$lang["invoice_color"] = "Rechnungsfarbe";
$lang["invoice_footer"] = "Fußzeile der Rechnung";
$lang["invoice_preview"] = "Vorschau";
$lang["close_preview"] = "Vorschau schließen";
$lang["only_me"] = "Nur ich";
$lang["specific_members_and_teams"] = "Bestimmte Mitglieder & Teams";
$lang["rows_per_page"] = "Zeilen pro Seite";
$lang["price"] = "Preis";
$lang["security_type"] = "Sicherheitstyp";

$lang["client_can_view_tasks"] = "Kann Aufgaben einsehen";
$lang["client_can_create_tasks"] = "Kann Aufgaben erstellen";
$lang["client_can_edit_tasks"] = "Kann Aufgaben bearbeiten";
$lang["client_can_comment_on_tasks"] = "Kann Aufgaben kommentieren";

$lang["set_project_permissions"] = "Projekt-Rechte";
$lang["can_create_projects"] = "Kann Projekte erstellen";
$lang["can_edit_projects"] = "Kann Projekte bearbeiten";
$lang["can_delete_projects"] = "Kann Projekte löschen";
$lang["can_create_tasks"] = "Kann Aufgaben erstellen";
$lang["can_edit_tasks"] = "Kann Aufgaben bearbeiten";
$lang["can_delete_tasks"] = "Kann Aufgaben löschen";
$lang["can_comment_on_tasks"] = "Kann Aufgaben kommentieren";
$lang["can_create_milestones"] = "Kann Meilensteine erstellen";
$lang["can_edit_milestones"] = "Kann Meilensteine bearbeiten";
$lang["can_delete_milestones"] = "Kann Meilensteine löschen";
$lang["can_add_remove_project_members"] = "Kann Mitglieder bearbeiten, entfernen & hinzufügen";
$lang["can_delete_files"] = "Kann Dateien löschen";

/* Version 1.2.2 */
$lang["label"] = "Label";
$lang["send_bcc_to"] = "Bei Rechnungsversand BCC an";
$lang["mark_project_as_completed"] = "Projekt abschließen";
$lang["mark_project_as_canceled"] = "Projekt abbrechen";
$lang["mark_project_as_open"] = "Projekt eröffnen";

/* Version 1.3 */
$lang["notification"] = "Benachrichtigung";
$lang["notifications"] = "Benachrichtigungen";
$lang["notification_settings"] = "Benachrichtigungs-Einstellungen";
$lang["enable_email"] = "E-Mail aktivieren";
$lang["enable_web"] = "Web aktivieren";
$lang["event"] = "Ereignis";
$lang["notify_to"] = "Benachrichtigte Personen";

$lang["project_created"] = "Projekt erstellt";
$lang["project_deleted"] = "Projekt gelöscht";
$lang["project_task_created"] = "Projektaufgabe erstellt";
$lang["project_task_updated"] = "Projektaufgabe aktualisiert";
$lang["project_task_assigned"] = "Projektaufgabe zugewiesen";
$lang["project_task_started"] = "Projektaufgabe begonnen";
$lang["project_task_finished"] = "Projektaufgabe beendet";
$lang["project_task_reopened"] = "Projektaufgabe wiedereröffnet";
$lang["project_task_deleted"] = "Projektaufgabe gelöscht";
$lang["project_task_commented"] = "Projektaufgabe kommentiert";
$lang["project_member_added"] = "Projektmitglied hinzugefügt";
$lang["project_member_deleted"] = "Projektmitglied entfernt";
$lang["project_file_added"] = "Projektdatei hinzugefügt";
$lang["project_file_deleted"] = "Projektdatei gelöscht";
$lang["project_file_commented"] = "Projektdatei kommentiert";
$lang["project_comment_added"] = "Projektkommentar hinzugefügt";
$lang["project_comment_replied"] = "Antwort auf Projektkommentar";
$lang["project_customer_feedback_added"] = "Kundenkommentar hinzugefügt";
$lang["project_customer_feedback_replied"] = "Antwort auf Kundenkommentar";
$lang["client_signup"] = "Kundenregistrierung";
$lang["invoice_online_payment_received"] = "Online-Rechnungszahlung erhalten";
$lang["leave_application_submitted"] = "Neue Freistellungsanfrage";
$lang["leave_approved"] = "Freistellung genehmigt";
$lang["leave_assigned"] = "Freistellung vergeben";
$lang["leave_rejected"] = "Freistellung abgelehnt";
$lang["leave_canceled"] = "Freistellungsanfrage abgebrochen";
$lang["ticket_created"] = "Ticket hinzugefügt";
$lang["ticket_commented"] = "Ticket kommentiert";
$lang["ticket_closed"] = "Ticket geschlossen";
$lang["ticket_reopened"] = "Ticket wiedereröffnet";
$lang["leave"] = "Freistellung";

$lang["client_primary_contact"] = "Primärer Ansprechpartner";
$lang["client_all_contacts"] = "Alle Ansprechnpartner";
$lang["task_assignee"] = "Zugewiesene/r (Aufgabe)";
$lang["task_collaborators"] = "Mitwirkende (Aufgabe)";
$lang["comment_creator"] = "Kommentar-Ersteller";
$lang["leave_applicant"] = "Antragsteller Freistellung";
$lang["ticket_creator"] = "Ticket-Ersteller";

$lang["no_new_notifications"] = "Keine aktuellen Benachrichtigungen.";

/* Notification messages */

$lang["notification_project_created"] = "Ein neues Projekt wurde erstellt.";
$lang["notification_project_deleted"] = "Ein Projekt wurde gelöscht.";
$lang["notification_project_task_created"] = "Eine neue Aufgabe wurde erstellt.";
$lang["notification_project_task_updated"] = "Eine Aufgabe wurde aktualisiert.";
$lang["notification_project_task_assigned"] = "Eine Aufgabe wurde %s zugewiesen"; //Assigned a task to Mr. X
$lang["notification_project_task_started"] = "Mit Aufgabe begonnen.";
$lang["notification_project_task_finished"] = "Eine Aufgabe wurde abgeschlossen.";
$lang["notification_project_task_reopened"] = "Wiedereröffnung einer Aufgabe.";
$lang["notification_project_task_deleted"] = "Eine Aufgabe wurde gelöscht.";
$lang["notification_project_task_commented"] = "Eine Aufgabe wurde kommentiert.";
$lang["notification_project_member_added"] = "%s wurde als Projektmitglied hinzugefügt."; //Added Mr. X in a project.
$lang["notification_project_member_deleted"] = "%s wurde als Projektmitglied entfernt."; //Deleted Mr. X from a project.
$lang["notification_project_file_added"] = "Neue Datei in einem Projekt.";
$lang["notification_project_file_deleted"] = "Eine Datei wurde von einem Projekt entfernt.";
$lang["notification_project_file_commented"] = "Eine Datei wurde kommentiert.";
$lang["notification_project_comment_added"] = "Ein Projekt wurde kommentiert.";
$lang["notification_project_comment_replied"] = "Neue Antwort auf ein Projektkommentar.";
$lang["notification_project_customer_feedback_added"] = "Ein Kunde hat ein Projekt kommentiert.";
$lang["notification_project_customer_feedback_replied"] = "Es wurde auf ein Kundenkommentar geantwortet.";
$lang["notification_client_signup"] = "hat sich als Kunde registriert."; //Mr. X signed up as a new client.
$lang["notification_invoice_online_payment_received"] = "Eine Online-Zahlung wurde getätigt / erhalten..";
$lang["notification_leave_application_submitted"] = "Eine neue Freistellung wurde beantragt.";
$lang["notification_leave_approved"] = "Freistellung von %s wurde genehmigt."; //Approve a leave of Mr. X
$lang["notification_leave_assigned"] = "Freistellung wurde an %s vergeben."; //Assigned a leave to Mr. X
$lang["notification_leave_rejected"] = "Freistellung von %s wurde abgelehnt."; //Approve a leave of Mr. X
$lang["notification_leave_canceled"] = "Ein Freistellungsantrag wurde abgebrochen.";
$lang["notification_ticket_created"] = "Ein neues Ticket wurde gesendet oder erstellt.";
$lang["notification_ticket_commented"] = "Ein Ticket wurde kommentiert.";
$lang["notification_ticket_closed"] = "Ein Ticket konnte geschlossen werden.";
$lang["notification_ticket_reopened"] = "Ein Ticket wurde neueröffnet.";

$lang["general_notification"] = "Allgemeine Benachrichtigung";

$lang["disable_online_payment"] = "Online-Zahlung deaktivieren";
$lang["disable_online_payment_description"] = "Online-Zahlung in Rechnungen dieses Kunden verstecken.";

$lang["client_can_view_project_files"] = "Kann Projektdateien einsehen";
$lang["client_can_add_project_files"] = "Kann Projektdateien hinzufügen";
$lang["client_can_comment_on_files"] = "Kann Projektdateien kommentieren";
$lang["mark_invoice_as_not_paid"] = "Als nicht gezahlt markieren"; //Change invoice status to Not Paid

$lang["set_team_members_permission"] = "Privatsphäre-Rechte";
$lang["can_view_team_members_contact_info"] = "Kann Kontaktinformationen der Mitglieder einsehen";
$lang["can_view_team_members_social_links"] = "Kann Social Links der Mitglieder einsehen";

$lang["collaborator"] = "Mitwirkende(r)";
$lang["collaborators"] = "Mitwirkende";

/* Version 1.4 */

$lang["modules"] = "Module";
$lang["manage_modules"] = "Module verwalten";
$lang["module_settings_instructions"] = "Module auswählen, die aktiviert sein sollen.";

$lang["task_point_help_text"] = "Erklärung: Punkte dienen der Errechnung des Fortschrittes eines Projekts. Die Punkte ALLER Aufgaben werden addiert, der Anteil der Punkte ERLEDIGTER Aufgaben bildet den Fortschritt des Projektes. Daher: 5 Punkte für große, 1 Punkt für kleine Aufgaben."; //meaning of task point

$lang["mark_as_open"] = "Als offen markieren";
$lang["mark_as_closed"] = "Als geschlossen markieren";

$lang["ticket_assignee"] = "Ticket-Zuständiger";

$lang["estimate"] = "Schätzung";
$lang["estimates"] = "Schätzungen";
$lang["estimate_request"] = "Anfrage Schätzung";
$lang["estimate_requests"] = "Anfragen Schätzung";
$lang["estimate_list"] = "Liste Schätzungen";
$lang["estimate_forms"] = "Formulare für Schätzung";
$lang["estimate_request_forms"] = "Formulare für Schätzung";

$lang["add_form"] = "Anfragenformular hinzufügen";
$lang["edit_form"] = "Anfragenformular bearbeiten";
$lang["delete_form"] = "Anfragenformular löschen";

$lang["add_field"] = "Feld hinzufügen";
$lang["placeholder"] = "Platzhalter";
$lang["required"] = "Notwendig";

$lang["field_type"] = "Feldtyp";
$lang["preview"] = "Vorschau";

$lang["field_type_text"] = "Text";
$lang["field_type_textarea"] = "Textfläche";
$lang["field_type_select"] = "Auswahl";
$lang["field_type_multi_select"] = "Multiauswahl";

$lang["request_an_estimate"] = "Schätzung anfordern";
$lang["estimate_submission_message"] = "Deine Anfrage wurde erfolgreich gesendet! Wir melden uns in Kürze.";

$lang["hold"] = "Schwebend";
$lang["processing"] = "In Abwicklung";
$lang["estimated"] = "Geschätzt";

$lang["add_estimate"] = "Schätzung hinzufügen";
$lang["edit_estimate"] = "Schätzung bearbeiten";
$lang["delete_estimate"] = "Schätzung löschen";
$lang["valid_until"] = "Gültig bis";
$lang["estimate_date"] = "Datum";
$lang["accepted"] = "Akzeptiert";
$lang["declined"] = "Abgelehnt";
$lang["sent"] = "Gesendet";
$lang["estimate_preview"] = "Vorschau";
$lang["estimate_to"] = "Schätzung für";

$lang["can_access_estimates"] = "Kann Schätzungen verwalten:";
$lang["request_an_estimate"] = "Schätzung anfordern";
$lang["estimate_request_form_selection_title"] = "Bitte wähle das Produkt, für welches Du eine Schätzung erhalten möchten.";

$lang["mark_as_processing"] = "Als 'In Abwicklung' markieren";
$lang["mark_as_estimated"] = "Als 'Geschätzt' markieren";
$lang["mark_as_hold"] = "Als 'Schwebend' markieren";
$lang["mark_as_canceled"] = "Als 'Abgebrochen' markieren";

$lang["mark_as_sent"] = "Als 'Gesendet' markieren";
$lang["mark_as_accepted"] = "Als 'Akzeptiert' markieren";
$lang["mark_as_rejected"] = "Als 'Zurückgewiesen' markieren";
$lang["mark_as_declined"] = "Als 'Abgelehnt' markieren";

$lang["estimate_request_received"] = "Anfrage für Schätzung erhalten";
$lang["estimate_sent"] = "Schätzung gesendet";
$lang["estimate_accepted"] = "Schätzung akzeptiert";
$lang["estimate_rejected"] = "Schätzung zurückgewiesen";

$lang["notification_estimate_request_received"] = "hat eine Schätzung angefordert";
$lang["notification_estimate_sent"] = "hat eine Schätzung gesendet";
$lang["notification_estimate_accepted"] = "hat eine Schätzung akzeptiert";
$lang["notification_estimate_rejected"] = "hat eine Schätzung zurückgewiesen";

$lang["clone_project"] = "Projekt klonen";
$lang["copy_tasks"] = "Aufgaben kopieren";
$lang["copy_project_members"] = "Mitglieder kopieren";
$lang["copy_milestones"] = "Meilensteine kopieren";
$lang["copy_same_assignee_and_collaborators"] = "Zugeordnete und Mitwirkende kopieren";
$lang["copy_tasks_start_date_and_deadline"] = "Start- und Enddaten der Aufgaben kopieren";
$lang["task_comments_will_not_be_included"] = "Kommentare werden nicht mitkopiert";
$lang["project_cloned_successfully"] = "Das Projekt wurde erfolgreich geklont";

$lang["search"] = "Suchen";
$lang["no_record_found"] = "Kein Eintrag gefunden.";
$lang["excel"] = "Excel";
$lang["print_button_help_text"] = "Wenn fertig, ESC drücken.";
$lang["are_you_sure"] = "Bist Du sicher?";
$lang["file_upload_instruction"] = "Dateien hier drag-and-droppen <br /> (oder klicken zum Auswählen...)";
$lang["file_name_too_long"] = "Dateiname ist zu lang.";
$lang["scrollbar"] = "Scrollbar";

$lang["short_sunday"] = "Son";
$lang["short_monday"] = "Mon";
$lang["short_tuesday"] = "Die";
$lang["short_wednesday"] = "Mit";
$lang["short_thursday"] = "Don";
$lang["short_friday"] = "Fre";
$lang["short_saturday"] = "Sam";

$lang["min_sunday"] = "So";
$lang["min_monday"] = "Mo";
$lang["min_tuesday"] = "Di";
$lang["min_wednesday"] = "Mi";
$lang["min_thursday"] = "Do";
$lang["min_friday"] = "Fr";
$lang["min_saturday"] = "Sa";

$lang["january"] = "Januar";
$lang["february"] = "Februar";
$lang["march"] = "März";
$lang["april"] = "April";
$lang["may"] = "Mai";
$lang["june"] = "Juni";
$lang["july"] = "Juli";
$lang["august"] = "August";
$lang["september"] = "September";
$lang["october"] = "Oktober";
$lang["november"] = "November";
$lang["december"] = "Dezember";

$lang["short_january"] = "Jan";
$lang["short_february"] = "Feb";
$lang["short_march"] = "Mär";
$lang["short_april"] = "Apr";
$lang["short_may"] = "Mai";
$lang["short_june"] = "Jun";
$lang["short_july"] = "Jul";
$lang["short_august"] = "Aug";
$lang["short_september"] = "Sep";
$lang["short_october"] = "Okt";
$lang["short_november"] = "Nov";
$lang["short_december"] = "Dez";

/* Version 1.5 */

$lang["no_such_file_or_directory_found"] = "Datei oder Verzeichnis existiert nicht.";
$lang["gantt"] = "Gantt";
$lang["not_specified"] = "Nicht angegeben";
$lang["group_by"] = "Gruppieren mit";
$lang["create_invoice"] = "Rechnung erstellen";
$lang["include_all_items_of_this_estimate"] = "Alle Posten der Schätzung miteinbeziehen";
$lang["edit_payment"] = "Zahlung bearbeiten";
$lang["disable_client_login"] = "Kundenanmeldung deaktivieren";
$lang["disable_client_signup"] = "Kundenregistrierung deaktivieren";

$lang["chart"] = "Diagramm";
$lang["signin_page_background"] = "Hintergrundbild";
$lang["show_logo_in_signin_page"] = "Logo auf Anmeldeseite";
$lang["show_background_image_in_signin_page"] = "Hintergrund auf Anmeldeseite";

/* Version 1.6 */

$lang["more"] = "Mehr";
$lang["custom"] = "Benutzerdefiniert";
$lang["clear"] = "Leeren";
$lang["expired"] = "Abgelaufen";
$lang["enable_attachment"] = "Anhang aktivieren";
$lang["custom_fields"] = "Eigene Felder";
$lang["edit_field"] = "Feld bearbeiten";
$lang["delete_field"] = "Feld löschen";
$lang["client_info"] = "Kundeninfo";
$lang["edit_expenses_category"] = "Ausgabenbereich bearbeiten";
$lang["eelete_expenses_category"] = "Ausgabenbereich löschen";
$lang["empty_starred_projects"] = "Um schnell auf Deine wichtigsten Projekte zuzugreifen, markiere diese in der Projektansicht mit einem Stern.";
$lang["empty_starred_clients"] = "Um schnell auf Deine wichtigsten Kunden zuzugreifen, markiere diese in der Kundenansicht mit einem Stern.";
$lang["download_zip_name"] = "dateiarchiv";
$lang["invoice_prefix"] = "Rechnungspräfix";
$lang["invoice_style"] = "Rechnungsstil";
$lang["delete_confirmation_message"] = "Dies kann nicht rückgängig gemacht werden!";
$lang["left"] = "Links";
$lang["right"] = "Rechts";
$lang["currency_position"] = "Position Währungssymbol";
$lang["recipient"] = "Empfänger";

$lang["new_message_sent"] = "Neue Nachricht gesendet";
$lang["message_reply_sent"] = "Antwortnachricht gesendet";
$lang["notification_new_message_sent"] = "Nachricht gesendet.";
$lang["notification_message_reply_sent"] = "Antwortnachricht gesendet.";
$lang["invoice_payment_confirmation"] = "Bestätigung Rechnungszahlung";
$lang["notification_invoice_payment_confirmation"] = "Rechnungszahlung erhalten.";

/* Version 1.7 */

$lang["client_can_create_projects"] = "Kann Projekte erstellen";
$lang["client_can_view_timesheet"] = "Kann Stundenzettel einsehen";
$lang["client_can_view_gantt"] = "Kann Gannt-Diagramme einsehen";
$lang["client_can_view_overview"] = "Kann Projektübersicht einsehen";
$lang["client_can_view_milestones"] = "Kann Meilensteine einsehen";

$lang["items"] = "Posten";
$lang["edit_item"] = "Posten bearbeiten";
$lang["item_edit_instruction"] = "Hinweis: Die Änderungen werden nicht auf bereits bestehende Rechnungen und Kostenvoranschläge angewandt.";

$lang["recurring"] = "Wiederholend";
$lang["repeat_every"] = "Wiederhole alle"; //Ex. repeat every 2 months
$lang["interval_days"] = "Tag(e)";
$lang["interval_weeks"] = "Woche(n)";
$lang["interval_months"] = "Monat(e)";
$lang["interval_years"] = "Jahr(e)";
$lang["cycles"] = "Durchläufe";
$lang["recurring_cycle_instructions"] = "Wiederholung wird nach Anzahl X an Durchläufen beendet. Freilassen für unendliche Wiederholung.";
$lang["next_recurring_date"] = "Datum der nächsten Wiederholung";
$lang["stopped"] = "Gestoppt";
$lang["past_recurring_date_error_message_title"] = "Das ausgewählte Rechnungsdatum und die Art der Wiederholung ergeben ein vergangenes Datum.";
$lang["past_recurring_date_error_message"] = "Das Datum der nächsten Wiederholung muss in der Zukunft liegen. Bitte wähle ein zukünftiges Datum aus.";
$lang["sub_invoices"] = "Unterrechnungen";

$lang["cron_job_required"] = "Hierfür wird ein Cron-Job benötigt!";

$lang["recurring_invoice_created_vai_cron_job"] = "Neue wiederholende Rechnung via Cron-Job erstellt";
$lang["notification_recurring_invoice_created_vai_cron_job"] = "Neue wiederholende Rechnung erstellt (Cron-Job)";

$lang["field_type_number"] = "Zahl";
$lang["show_in_table"] = "In Tabelle zeigen";
$lang["show_in_invoice"] = "In Rechnung zeigen";
$lang["visible_to_admins_only"] = "Nur für Administratoren sichtbar";
$lang["hide_from_clients"] = "Vor Kunden verbergen";
$lang["public"] = "Öffentlich";

$lang["help"] = "Internes Wiki";
$lang["articles"] = "Artikel";
$lang["add_article"] = "Neuen Artikel hinzufügen";
$lang["edit_article"] = "Artikel bearbeiten";
$lang["delete_article"] = "Artikel löschen";
$lang["can_manage_help_and_knowledge_base"] = "Kann internes Wiki und Wissensbasis verwalten:";

$lang["how_can_we_help"] = "Wie können wir helfen?";
$lang["help_page_title"] = "Wiki (Intern)";
$lang["search_your_question"] = "Frage eingeben...";
$lang["no_result_found"] = "Kein Ergebnis gefunden.";
$lang["sort"] = "Sortieren";
$lang["total_views"] = "Aufrufe insgesamt";

$lang["help_and_support"] = "Hilfe & Wissen";
$lang["knowledge_base"] = "Wissensbasis";

$lang["payment_success_message"] = "Deine Zahlung wurde abgeschlossen.";
$lang["payment_card_charged_but_system_error_message"] = "Deine Karte wird möglicherweise belastet, doch wir können den Zahlungsprozess derzeit nicht abschließen. Bitte kontakiere einen Administrator.";
$lang["card_payment_failed_error_message"] = "Wir können den Zahlungsprozess derzeit nicht durchführen. Bitte versuche es später noch einmal.";

$lang["message_received"] = "Nachricht erhalten";
$lang["in_number_of_days"] = "In %s Tag(en)"; //Ex. In 7 days
$lang["details"] = "Details";
$lang["summary"] = "Zusammenfassung";
$lang["project_timesheet"] = "Projekt-Stundenzettel";

$lang["set_event_permissions"] = "Kalender-Rechte";
$lang["disable_event_sharing"] = "Teilen von Terminen deaktivieren";
$lang["can_update_team_members_general_info_and_social_links"] = "Kann Infos und Social Links von Mitgliedern verwalten:";
$lang["can_manage_team_members_project_timesheet"] = "Kann Stundenzettel verwalten:";

$lang["cron_job"] = "Cron-Job";
$lang["cron_job_link"] = "Cron-Job Link";
$lang["last_cron_job_run"] = "Letze Ausführung";
$lang["created_from"] = "Erstellt durch"; //Ex. Created from Invoice#1
$lang["recommended_execution_interval"] = "Empfohlenes Intervall";

/* Version 1.8 */

$lang["integration"] = "Integrationen";
$lang["get_your_key_from_here"] = "Hier erhältst Du Deine Schlüssel:";
$lang["re_captcha_site_key"] = "Seitenschlüssel";
$lang["re_captcha_secret_key"] = "Geheimschlüssel";

$lang["re_captcha_error-missing-input-secret"] = "Der Geheimschlüssel für das reCAPTCHA fehlt.";
$lang["re_captcha_error-invalid-input-secret"] = "Der Geheimschlüssel für das reCAPTCHA ist ungültig.";
$lang["re_captcha_error-missing-input-response"] = "Bitte löse das reCAPTCHA.";
$lang["re_captcha_error-invalid-input-response"] = "Das reCAPTCHA wurde nicht korrekt gelöst. Bitte wiederhole den Vorgang.";
$lang["re_captcha_error-bad-request"] = "ERROR: Die Anfrage kann derzeit nicht verarbeitet werden.";
$lang["re_captcha_expired"] = "Das reCAPTCHA ist abgelaufen. Bitte lade die Seite neu.";

$lang["yes_all_tickets"] = "Ja, alle Tickets";
$lang["choose_ticket_types"] = "Ticket-Typen auswählen";

$lang["can_manage_all_projects"] = "Kann alle Projekte verwalten";
$lang["show_most_recent_ticket_comments_at_the_top"] = "Neueste Ticket-Kommentare ganz oben zeigen";

$lang["new_event_added_in_calendar"] = "Neuer Termin zum Kalender hinzugefügt";
$lang["notification_new_event_added_in_calendar"] = "Neuer Termin hinzugefügt.";

$lang["todo"] = "To-Do";
$lang["add_a_todo"] = "To-Do hinzufügen";

/* Version 1.9 */

$lang["client_groups"] = "Kundengruppen";
$lang["add_client_group"] = "Kundengruppe hinzufügen";
$lang["edit_client_group"] = "Kundengruppe bearbeiten";
$lang["delete_client_group"] = "Kundengruppe löschen";

$lang["ticket_prefix"] = "Ticketpräfix";
$lang["add_a_task"] = "Aufgabe hinzufügen...";

$lang["add_task_status"] = "Aufgabenstatus hinzufügen";
$lang["edit_task_status"] = "Aufgabenstatus bearbeiten";
$lang["delete_task_status"] = "Aufgabenstatus löschen";

$lang["list"] = "Liste";
$lang["kanban"] = "Kanban";
$lang["priority"] = "Priorität";
$lang["moved_up"] = "Erhöht";
$lang["moved_down"] = "Verringert";
$lang["mark_project_as_hold"] = "Projekt pausieren";

$lang["repeat"] = "Wiederholen";

$lang["hide_team_members_list"] = "Liste der Mitglieder verstecken?";

/* Version 2.0 */

$lang["summary_details"] = "Details";

$lang["chat"] = "Chat";
$lang["my_preferences"] = "Meine Einstellungen";
$lang["show_push_notification"] = "Zeige Push-Benachrichtigung";
$lang["notification_sound_volume"] = "Lautstärke für Benachrichtigungen";

$lang["project_reference_in_tickets"] = "Projekt-Referenz aktivieren";

$lang["hide_menus_from_client_portal"] = "Folgende Menüs für Kunden verstecken:";
$lang["hidden_menus"] = "Versteckte Menüs";

$lang["new_announcement_created"] = "Neue Ankündigung erstellt";
$lang["notification_new_announcement_created"] = "hat eine Ankündigung erstellt.";

$lang["month"] = "Monat";
$lang["profit"] = "Gewinn";

$lang["invoice_due_reminder_before_due_date"] = "Zahlungserinnerung (Rechnung fällig)";
$lang["send_due_invoice_reminder_notification_before"] = "Zahlungserinnerung für fällige Rechnungen senden";
$lang["send_invoice_overdue_reminder_after"] = "Zahlungserinnerung für überfällige Rechnungen senden";
$lang["invoice_overdue_reminder"] = "Zahlungserinnerung (Rechnung überfällig)";
$lang["recurring_invoice_creation_reminder"] = "Erinnerung: Wiederholende Rechnung wird erstellt";
$lang["send_recurring_invoice_reminder_before_creation"] = "Erinnerung für wiederholende Rechnung (vor Erstellung)";

$lang["notification_invoice_due_reminder_before_due_date"] = "Erinnerung: Rechnung fällig";
$lang["notification_invoice_overdue_reminder"] = "Erinnerung: Rechnung überfällig";
$lang["notification_recurring_invoice_creation_reminder"] = "Eine wiederholende Rechnung wird in Kürze erstellt.";

$lang["can_delete_leave_application"] = "Kann Freistellungsanfragen löschen";
$lang["no_of_decimals"] = "Dezimalstellenanzahl";

$lang["checklist"] = "Checkliste";
$lang["delete_checklist_item"] = "Lösche Listeneintrag";

$lang["save_and_show"] = "Speichern und anzeigen";
$lang["total_leave_yearly"] = "Freistellungen insgesamt (Jährlich)";

$lang["new_conversation"] = "Neue Nachricht";

$lang["enable_web_notification"] = "Web-Benachrichtigungen aktivieren";
$lang["enable_email_notification"] = "E-Mail-Benachrichtigungen aktivieren";

/* Version 2.0.3 */

$lang["show_in_estimate"] = "Zeige in der Schätzung";
$lang["mentioned_members"] = "Erwähnte Mitglieder";
$lang["all"] = "Alle";

$lang["confirmed"] = "Zugesagt";
$lang["confirm"] = "Zusagen";

$lang["confirmed_by"] = "Zugesagt von";
$lang["confirm_event"] = "Termin zusagen";
$lang["reject_event"] = "Termin absagen";
$lang["event_status"] = "Terminstatus";

$lang["specific_client_contacts"] = "Bestimmte Ansprechpartner";
$lang["choose_client_contacts"] = "Wähle Ansprechpartner";
$lang["invitations_sent"] = "Die Einladungen wurden versandt.";

/* Version 2.1 */

$lang["add_new_dashboard"] = "Neues Dashboard hinzufügen";
$lang["add_row"] = "Zeile hinzufügen";

$lang["available_widgets"] = "Verfügbare Module";
$lang["your_selected_widgets_will_be_appear_here"] = "Die von Dir ausgewählten Module werden hier erscheinen.";
$lang["drag_and_drop_widgets_here"] = "Module hierherziehen";
$lang["no_more_widgets_available"] = "Keine weiteren Module verfügbar";
$lang["invalid_widget_access"] = "Du hast keinen Zugriff auf dieses Modul.";

$lang["dashboard_title"] = "Titel des Dashboards";
$lang["edit_dashboard"] = "Dashboard bearbeiten";
$lang["edit_title"] = "Titel bearbeiten";
$lang["default_dashboard"] = "Standard-Dashboard";

$lang["widget"] = "Modul";
$lang["widgets"] = "Module";
$lang["add_widget"] = "Modul hinzufügen";
$lang["edit_widget"] = "Modul bearbeiten";
$lang["delete_widget"] = "Modul löschen";

$lang["content"] = "Inhalt";
$lang["clock_in_out"] = "Ein-/Ausstempeln";
$lang["custom_widget_details"] = "Benutzerdefinierte Modul-Details";

$lang["total_projects"] = "Projekte insgesamt";
$lang["total_invoices"] = "Rechnungen insgesamt";
$lang["total_payments"] = "Zahlungen insgesamt";
$lang["total_due"] = "Insgesamt überfällig";

$lang["show_title"] = "Titel zeigen";
$lang["show_border"] = "Rahmen zeigen";

$lang["all_tasks_kanban"] = "All tasks kanban";
$lang["todo_list"] = "To-Do Liste";
$lang["open_projects_list"] = "Öffne Projektliste";
$lang["starred_projects"] = "Mit Stern markierte Projekte";
$lang["completed_projects"] = "Abgeschlossen ";

$lang["new_tickets"] = "Neue Tickets";
$lang["closed_tickets"] = "Geschlossene Tickets";

$lang["clocked_in_team_members"] = "Eingestempelte Mitglieder";
$lang["clocked_out_team_members"] = "Ausgestempelte Mitglieder";
$lang["latest_online_client_contacts"] = "Zuletzt angemeldete Kunden";
$lang["latest_online_team_members"] = "Zuletzt angemeldete Mitglieder";
$lang["my_tasks_list"] = "Meine Aufgabenliste";

$lang["discount"] = "Rabatt";
$lang["discount_type"] = "Rabatt-Art";
$lang["edit_discount"] = "Rabatt bearbeiten";
$lang["discount_amount"] = "Höhe des Rabatts";
$lang["fixed_amount"] = "Feste Höhe";
$lang["before_tax"] = "Vor Steuer";
$lang["after_tax"] = "Nach Steuer";

$lang["access_permission"] = "Zugriffsberechtigungen";
$lang["setup"] = "Setup";
$lang["client_permissions"] = "Kundenberechtigungen";

$lang["invoice_over_payment_error_message"] = "Du kannst nicht mehr bezahlen als fällig.";
$lang["account_already_exists_for_your_company_name"] = "Konto für Deinen Firmennamen besteht bereits.";
$lang["personal_language"] = "Persönliche Sprache";
$lang["no_messages_text"] = "Du hast noch keine Nachrichten";
$lang["no_users_found"] = "Keine Benutzer gefunden";

$lang["create_project"] = "Projekt erstellen";

/* Version 2.2 */

$lang["imap_settings"] = "IMAP-Einstellungen";
$lang["enable_email_piping"] = "E-Mail-Piping aktivieren";
$lang["imap_host"] = "IMAP-Server";
$lang["imap_port"] = "Port";
$lang["imap_ssl_enabled"] = "SSL aktiviert";
$lang["please_upgrade_your_php_version"] = "Bitte aktualisiere für diese Aktion Deine PHP-Version.";
$lang["required_version"] = "Benötigte Version";
$lang["email_piping_help_message"] = "Bitte stelle sicher, dass der IMAP-Zugriff aktiviert ist.";

$lang["enable_rich_text_editor"] = "Verwende Rich-Text-Editor, wo möglich";

$lang["show_assigned_tasks_only"] = "Zeige nur zugewiesene Aufgaben";

$lang["batch_update"] = "Stapelaktualisierung";
$lang["cancel_selection"] = "Auswahl abbrechen";
$lang["select_status"] = "Status auswählen";

$lang["add_multiple_tasks"] = "+ Mehrere Aufgaben";
$lang["save_and_add_more"] = "Speichern & mehr hinzufügen";
$lang["add_project_time"] = "Füge Projekt-Zeit hinzu";
$lang["add_to_do"] = "To-Do schreiben";
$lang["hide_menus_from_topbar"] = "Verberge Menüs bei der oberen Leiste";
$lang["favorite_projects"] = "Markierte Projekte";
$lang["favorite_clients"] = "Markierte Kunden";
$lang["dashboard_customization"] = "Dashboard-Anpassung";
$lang["quick_add"] = "Schnell hinzufügen";

$lang["assign_to_me"] = "Mir zuweisen";

$lang["favicon"] = "Favicon";

$lang["enable_google_drive_api_to_upload_file"] = "Google Drive für Uploads verwenden";
$lang["drive_activation_help_message"] = "Wenn aktiv, werden von nun an alle Dateien zu Google Drive hochgeladen.";

$lang["mark_all_as_read"] = "Als gelesen markieren";
$lang["marked_all_notifications_as_read"] = "Alle Benachrichtigungen als gelesen markiert";

$lang["project_completed"] = "Projekt abgeschlossen";
$lang["notification_project_completed"] = "Hat ein Projekt abgeschlossen";

$lang["google_drive_client_id"] = "Client ID";
$lang["google_drive_client_secret"] = "Client Secret";
$lang["get_your_app_credentials_from_here"] = "Hier erhältst du Deine Schlüssel:";
$lang["remember_to_add_this_url_in_authorized_redirect_uri"] = "Denk daran, diese URL zu Deinen autorisierten URLs hinzuzufügen.";
$lang["save_and_authorize"] = "Speichern und autorisieren";

$lang["preview_next_key"] = "Weiter (rechter Pfeil)";
$lang["preview_previous_key"] = "Zurück (linker Pfeil)";

$lang["filters"] = "Filter";

$lang["authorized"] = "Autorisiert";
$lang["unauthorized"] = "Unautorisiert";

$lang["not_clocked_id_yet"] = "Nicht eingestempelt";

$lang["create_estimate_request"] = "Erstelle eine Anfrage";

$lang["in_last_number_of_days"] = "In den letzten %s Tagen";
$lang["in_last_number_of_month"] = "Im letzten %s Monat";
$lang["in_last_number_of_months"] = "In den letzten %s Monaten";

$lang["pusher_app_id"] = "App ID";
$lang["pusher_key"] = "Key";
$lang["pusher_secret"] = "Secret";
$lang["pusher_cluster"] = "Cluster";
$lang["enable_push_notification"] = "Push-Benachrichtigungen aktivieren";
$lang["push_notification"] = "Push-Benachrichtigung";
$lang["disable_push_notification"] = "Push-Benachrichtigung deaktivieren";

$lang["unknown_client"] = "Unbekannter Kunde";

$lang["income_expenses_widget_help_message"] = "Dieser Bericht ist nur nutzbar, wenn Du eine einzelne Währung verwendest.";

$lang["assign_myself_in_this_ticket"] = "Mir dieses Ticket selbst zuweisen";

$lang["create_new_task"] = "Neue Aufgabe erstellen";

$lang["default_due_date_after_billing_date"] = "Standard-Fälligkeitsdatum nach Rechnungsdatum";

$lang["field_type_external_link"] = "Externer Link";

$lang["total_days"] = "Tage insgesamt";

$lang["my_timesheet"] = "Mein Stundenzettel";
$lang["all_timesheets"] = "Alle Stundenzettel";
$lang["my_timesheet_statistics"] = "Statistiken meiner Stundenzettel";
$lang["all_timesheets_statistics"] = "Statistiken aller Stundenzettel";

$lang["no_field_has_selected"] = "Kein Feld ausgewählt!";

$lang["imap_help_message_1"] = "Du kannst ein E-Mail-Postfach einrichten, bei welchem eingehende E-Mails automatisch als Tickets behandelt und angelegt werden.";
$lang["imap_help_message_2"] = "Bitte denk daran, dass das System Tickets auf Basis der ungelesen E-Mails im Postfach anlegt. Nachdem die Tickets erstellt wurden, wird die jeweilige E-Mail als gelesen markiert. Um die Möglichkeit für Antworten innerhalb des Tickets zu schaffen, prüft das System nach der Ticket-ID im Betreff der E-Mails. Falls keine Ticket-ID erkannt wird, wird Sie als neues Ticket verwendet. Du kannst den E-Mail-Betreff bearbeiten bei den";
$lang["imap_error_credentials_message"] = "Fehler! Kann nicht mit dem IMAP-Server verbinden.";

$lang["client_message_own_contacts"] = "Kunde kann mit Kontakten derselben Firma kommunizieren";

$lang["print_invoice"] = "Rechnung drucken";

$lang["mark_invoice_as_cancelled"] = "Als storniert markieren";
$lang["cancelled"] = "Storniert";
$lang["cancelled_at"] = "Storniert am";
$lang["cancelled_by"] = "Storniert von";

/* Version 2.3 */

$lang["test_push_notification"] = "Testen Sie die Push-Benachrichtigung";
$lang["notification_test_push_notification"] = "Es ist eine Demo-Push-Benachrichtigung";
$lang["push_notification_error_message"] = "Error! Über die Anmeldeinformationen kann keine Verbindung zum Pusher hergestellt werden.";
$lang["clone_estimate"] = "Schätzung Klonen";

$lang["import_clients"] = "Clients importieren";
$lang["download_sample_file"] = "Beispieldatei herunterladen";

$lang["estimate_settings"] = "Schätzung Einstellungen";
$lang["estimate_logo"] = "Schätzung Logo";
$lang["estimate_color"] = "Schätzung Farbe";
$lang["initial_number_of_the_estimate"] = "Anfängliche Nummer der Schätzung";
$lang["the_estimates_id_must_be_larger_then_last_estimate_id"] = "Die Schätzungs-ID muss größer sein als die letzte Schätzungs-ID.";

$lang["send_to_client"] = "An Kunden senden";
$lang["estimate_sent_message"] = "Die Schätzung wurde gesendet!";
$lang["send_estimate_bcc_to"] = "Wenn Sie eine Schätzung an den Kunden senden, senden Sie BCC an";

$lang["task_settings"] = "Aufgaben einstellungen";
$lang["enable_recurring_option_for_tasks"] = "Aktivieren Sie die wiederkehrende Option für Aufgaben";
$lang["past_recurring_date_error_message_title_for_tasks"] = "Das ausgewählte Startdatum und der ausgewählte Wiederholungstyp geben ein vergangenes Datum zurück.";
$lang["recurring_task_created_via_cron_job"] = "Wiederkehrende Aufgabe über Cron Job erstellt";
$lang["notification_recurring_task_created_via_cron_job"] = "Neue Aufgabe erstellt";
$lang["repeat_type"] = "Typ wiederholen";
$lang["lead_status"] = "Interessenten-Status";
$lang["add_lead_status"] = "Interessenten-Status hinzufügen";
$lang["edit_lead_status"] = "Interessenten-Status bearbeiten";
$lang["delete_lead_status"] = "Interessenten-Status löschen";
$lang["owner"] = "Inhaberin";
$lang["make_client"] = "Client machen";
$lang["client_contacts"] = "Kundenkontakte";
$lang["lead_contacts"] = "Interessenten-Kontakte";
$lang["add_a_lead"] = "Fügen Sie einen Interessent hinzu";
$lang["source"] = "Quelle";
$lang["lead_source"] = "Bleiquelle";
$lang["add_lead_source"] = "Interessenten-Quelle hinzufügen";
$lang["edit_lead_source"] = "Bearbeiten Sie die Interessent-Quelle";
$lang["delete_lead_source"] = "Interessenten-Quelle löschen";
$lang["custom_field_migration"] = "Benutzerdefinierte Feldmigration";
$lang["merge_custom_fields"] = "Benutzerdefinierte Felder zusammenführen";
$lang["do_not_merge"] = "Nicht zusammenführen";
$lang["merge_custom_fields_help_message"] = "Wenn für %s ähnliche benutzerdefinierte Felder vorhanden sind, werden diese Werte zu diesen hinzugefügt. Andernfalls werden neue benutzerdefinierte Felder für %s erstellt und diesen Werte hinzugefügt.";
$lang["lead_created"] = "Interessenten erstellt";
$lang["notification_lead_created"] = "Erstellt einen neuen Interessenten.";
$lang["client_created_from_lead"] = "Kunde aus Interessent erstellt";
$lang["notification_client_created_from_lead"] = "Interessent in Kunden konvertiert.";
$lang["project_deadline"] = "Projekttermin";
$lang["task_deadline"] = "Aufgaben frist";
$lang["event_type"] = "Ereignistyp";
$lang["delete_estimate_form"] = "Formular für Schätzung löschen";
$lang["calendar_event_modified"] = "Kalenderereignis geändert";
$lang["notification_calendar_event_modified"] = "Modifizierte ein Ereignis.";

$lang["there_has_leads_with_this_status"] = "Es gibt Interessenten mit diesem Status";
$lang["lead_created_at"] = "Interessent erstellt am";
$lang["past_lead_information"] = "Frühere Interessenten-Informationen";
$lang["last_status"] = "Letzter Status";
$lang["migrated_to_client_at"] = "Migriert zum Client um";
$lang["edit_estimate_form"] = "Formular für Schätzung bearbeiten";

$lang["please_upload_a_excel_file"] = "Bitte laden Sie eine Excel-Datei hoch.";
$lang["back"] = "Zurück";

$lang["import_client_error_header"] = "Es gibt einen ungültigen Header. Das angegebene Feld sollte sein <b>%s</b>.";
$lang["import_client_error_company_name_field_required"] = "Das Feld für den Firmennamen ist erforderlich.";
$lang["import_client_error_contact_name"] = "Der Vor- und Nachname des Kontakts ist erforderlich, um einen Kundenkontakt hinzuzufügen.";
$lang["import_client_error_contact_email"] = "Kontakt-E-Mail ist erforderlich und sollte eindeutig sein, um einen Kundenkontakt hinzuzufügen.";
$lang["error"] = "Error";
$lang["contact_first_name"] = "Kontakt Vorname";
$lang["contact_last_name"] = "Kontakt Nachname";
$lang["contact_email"] = "Kontakt E-mail";

$lang["clone_invoice"] = "Clone Rechnung";
$lang["copy_items"] = "Elemente kopieren";
$lang["copy_discount"] = "Kopierrabatt";

$lang["clone_task"] = "Aufgabe klonen";
$lang["copy_checklist"] = "Checkliste kopieren";

$lang["auto_assign_estimate_request_to"] = "Anfrage für Schätzung automatisch zuweisen";

$lang["email_template_variable"] = "E-Mail-Vorlagenvariable";
$lang["example_variable_name"] = "Example_variable_name";

$lang["imap_extension_error_help_message"] = "Sie haben keine IMAP-Erweiterung auf Ihrem Server. Bitte installieren Sie die Erweiterung für diese Aktion.";

$lang["initial_number_of_the_invoice"] = "Anfangsnummer der Rechnung";
$lang["the_invoices_id_must_be_larger_then_last_invoice_id"] = "Die Rechnungs-ID muss größer sein als die letzte Rechnungs-ID.";

$lang["client_dashboard_help_message"] = "Dies ist das Standard-Dashboard für alle Clients. Bitte beachten Sie, dass die Informationen, die Sie hier in den Widgets sehen, keine tatsächlichen Informationen von Kunden sind.";

$lang["send_to_lead"] = "An Interessent senden";
$lang["lead"] = "Interessent";
$lang["leads"] = "Interessenten";
$lang["add_lead"] = "Interessent hinzufügen";
$lang["edit_lead"] = "Interessent bearbeiten";
$lang["delete_lead"] = "Interessent löschen";
$lang["lead_details"] = "Interessenten-Details";
$lang["can_access_leads_information"] = "Kann auf Interessenten-Informationen zugreifen?";
$lang["lead_info"] = "Interessent Info";

$lang["send_task_reminder_on_the_day_of_deadline"] = "Senden Sie die Aufgabenerinnerung am Tag der Frist";
$lang["send_task_deadline_pre_reminder"] = "Senden Sie die Aufgabenfrist vor der Erinnerung";
$lang["send_task_deadline_overdue_reminder"] = "Überfällige Erinnerung an die Aufgabenfrist senden";

$lang["project_task_deadline_reminder"] = "Erinnerung an die Frist für die Projektaufgabe";

$lang["project_task_deadline_pre_reminder"] = "Frist für die Projektaufgabe vor der Erinnerung";
$lang["project_task_deadline_overdue_reminder"] = "Überfällige Erinnerung an die Projektaufgabe";
$lang["project_task_reminder_on_the_day_of_deadline"] = "Erinnerung an die Projektaufgabe am Stichtag";

$lang["notification_project_task_deadline_pre_reminder"] = "Erinnerung: Einige Aufgaben müssen bald erledigt sein.";
$lang["notification_project_task_deadline_overdue_reminder"] = "Erinnerung: Die Frist für die Aufgabe ist überfällig.";
$lang["notification_project_task_reminder_on_the_day_of_deadline"] = "Erinnerung: Einige Aufgaben müssen heute erledigt werden.";

$lang["mark_as_public"] = "Als öffentlich markieren";
$lang["note_details"] = "Details beachten";
$lang["public_note_by"] = "Öffentliche Notiz durch";
$lang["marked_as_public"] = "Als öffentlich markiert";

$lang["client_can_view_activity"] = "Client kann Projektaktivität ansehen";

$lang["event_settings"] = "Ereigniseinstellungen";
$lang["enable_google_calendar_api"] = "Aktivieren Sie die Google Kalender-API";
$lang["google_calendar_settings"] = "Google Kalender einstellungen";

$lang["your_calendar_ids"] = "Ihre Kalender-IDs";
$lang["calendar_id"] = "Kalender-ID";
$lang["now_every_user_can_integrate_with_their_google_calendar"] = "Jetzt kann jeder Nutzer in seinen Google-Kalender integrieren.";
$lang["calendar_ids_help_message"] = "Sie erhalten immer Ihre eigenen Kalenderereignisse. Dies gilt für andere Sonderkalender (wie Feiertagskalender).";

$lang["google_client_id"] = "Kunden ID";
$lang["google_client_secret"] = "Client-Geheimnis";
$lang["integrate_with_google_calendar"] = "In Google Kalender integrieren";
$lang["google_calendar_event"] = "Google Kalender-Ereignis";

$lang["mark_as_public_help_message"] = "Sie können diese Notiz nicht wieder als privat kennzeichnen.";

$lang["google_calendar_help_message"] = "Sie erhalten Ihre Google Kalender-Ereignisse durch Ausführen des Cron-Jobs. Und jede Hinzufügung / Änderung Ihrer lokalen Ereignisse wirkt sich sofort auf Ihren Google-Kalender aus.";

/* Version 2.4 */

$lang["footer"] = "Fusszeile";
$lang["footer_description_message"] = "Diese Fußzeile ist auf allen öffentlichen Seiten sichtbar.";
$lang["estimate_footer"] = "Schätzung Footer";
$lang["enable_footer"] = "Fußzeile aktivieren";
$lang["footer_menus"] = "Fußzeilenmenüs";
$lang["footer_copyright_text"] = "Copyright-Text";
$lang["edit_footer_menu"] = "Fußzeilenmenü bearbeiten";

$lang["menu_name"] = "Menüname";
$lang["task_point_range"] = "Aufgabe Punktbereich";

$lang["gdpr"] = "GDPR";
$lang["enable_gdpr"] = "aktivieren GDPR";
$lang["allow_clients_to_export_their_data"] = "Ermöglichen Sie Clients, ihre Daten zu exportieren";
$lang["export_my_data"] = "Exportiere meine Daten";

$lang["clients_can_request_account_removal"] = "Kunden können die Entfernung des Kontos beantragen";
$lang["i_want_to_remove_my_account"] = "Ich möchte mein Konto entfernen";
$lang["client_contact_requested_account_removal"] = "Der Kundenkontakt forderte die Entfernung des Kontos an";
$lang["notification_client_contact_requested_account_removal"] = "Angeforderte Kontoentfernung.";
$lang["show_terms_and_conditions_in_client_signup_page"] = "Allgemeine Geschäftsbedingungen auf der Kundenanmeldeseite anzeigen";
$lang["i_accept_the_terms_and_conditions"] = "Ich akzeptiere die";

$lang["apply"] = "Anwenden";
$lang["applied"] = "Angewandt";
$lang["export"] = "Export";

$lang["pages"] = "Seiten";
$lang["add_page"] = "Seite hinzufügen";
$lang["delete_page"] = "Seite löschen";
$lang["page_url_cant_duplicate"] = "Die Seiten-URL kann nicht dupliziert werden.";

$lang["sub_tasks"] = "Unteraufgaben";
$lang["sub_task"] = "Unteraufgabe";
$lang["create_a_sub_task"] = "Erstellen Sie eine Unteraufgabe";
$lang["create"] = "Erstellen";
$lang["parent_task"] = "Übergeordnete Aufgabe";

$lang["this_task_blocked_by"] = "Diese Aufgabe wurde von blockiert";
$lang["this_task_blocking"] = "Diese Aufgabe des blockierung";
$lang["add_dependency"] = "Abhängigkeit hinzufügen";
$lang["blocked_by"] = "Blockiert von";
$lang["blocking"] = "Blockierung";
$lang["blocked"] = "Blockiert";
$lang["dependency"] = "Abhängigkeit";

$lang["estimate_request_settings"] = "Einstellungen für Schätzungs-Anfrage";
$lang["hidden_client_fields_on_public_estimate_requests"] = "Blenden Sie Felder vor öffentlichen Schätzungsformularen aus";
$lang["hidden_client_fields"] = "Versteckte Clientfelder";

$lang["account"] = "Konto";
$lang["common"] = "Verbreitet";

$lang["tax_deducted_at_source"] = "TDS";
$lang["auto_close_ticket_after"] = "Ticket automatisch schließen nach"; //after x days
$lang["disable_user_invitation_option_by_clients"] = "Deaktivieren Sie die Benutzereinladungsoption durch Clients";
$lang["create_tickets_only_by_registered_emails"] = "Erstellen Sie Tickets nur per registrierten E-Mail";
$lang["icon"] = "Ikone";
$lang["help_articles"] = "Hilfeartikel";
$lang["help_categories"] = "Hilfekategorien";
$lang["knowledge_base_articles"] = "KB-Artikel";
$lang["knowledge_base_categories"] = "KB-Kategorien";

$lang["rtl"] = "RTL";

$lang["disable_editing_by_clients"] = "Deaktivieren Sie die Bearbeitung durch Clients";

$lang["client_left_menu"] = "Linkes Menü";
$lang["left_menu_for_client"] = "Linkes Menü für Client";
$lang["left_menu_setting_help_message_for_client"] = "Dies ist das Standardmenü für Clients. Bitte beachten Sie, dass die Menüpunkte gemäß den Berechtigungen des Kundenkontakts verteilt werden.";
$lang["available_menu_items"] = "Verfügbare Menüpunkte";
$lang["drag_and_drop_items_here"] = "Ziehen Sie hier Elemente per Drag & Drop";
$lang["no_more_items_available"] = "Keine weiteren Artikel verfügbar";
$lang["left_menu_preview_message"] = "Klicken Sie auf die Schaltfläche Speichern, um die Vorschau anzuzeigen.";
$lang["left_menu_setting_help_message"] = "Dies ist das Standardmenü für Teammitglieder. Bitte beachten Sie, dass die Menüpunkte gemäß der Erlaubnis des Benutzers verteilt werden.";

$lang["draft_invoices"] = "Rechnungsentwurf";
$lang["draft_invoices_total"] = "Rechnungsentwurf insgesamt";
$lang["draft_invoices_value"] = "Rechnungsentwurf Wert";

$lang["gdpr_terms_and_conditions_link"] = "Allgemeine Geschäftsbedingungen URL";
$lang["gdpr_terms_and_conditions"] = "Geschäftsbedingungen";
$lang["removal_request_pending"] = "Entfernungsanforderung ausstehend";

$lang["client_access_files_help_message"] = "Die Dateien, die sich in der Client-Detailansicht befinden, werden auf der Registerkarte Dateien angezeigt.";
$lang["estimate_request_name_email_error_message"] = "E-Mails können nicht ohne Vor- und Nachnamen angezeigt werden.";

$lang["slug"] = "Schnecke";
$lang["add_assignee"] = "Bevollmächtigten hinzufügen";

$lang["client_can_pay_invoice_without_login"] = "Der Kunde kann Rechnungen ohne Login bezahlen";
$lang["client_can_pay_invoice_without_login_help_message"] = "Bitte fügen Sie die PUBLIC_PAY_INVOICE_URL in die Rechnungs-E-Mail-Benachrichtigungsvorlage ein.";

$lang["link_to_existing_client"] = "Link zum bestehenden Client";
$lang["link_to_new_client"] = "Link zum neuen Kunden";

$lang["client_can_view_files"] = "Client kann Dateien anzeigen?";
$lang["client_can_add_files"] = "Client kann Dateien hinzufügen?";
$lang["client_can_view_activity"] = "Kunde kann Projektaktivität anzeigen?";
$lang["client_can_edit_projects"] = "Client kann Projekte bearbeiten?";

$lang["view_pdf"] = "PDF anzeigen";

$lang["add_new_task"] = "Neue Aufgabe hinzufügen";
$lang["disable_keyboard_shortcuts"] = "Deaktivieren Sie Tastaturkürzel";
$lang["keyboard_shortcuts_info"] = "Informationen zu Tastaturkürzeln";
$lang["edit_shortcuts"] = "Tastaturkürzeln bearbeiten";

$lang["pending_leave_approval"] = "Genehmigung des ausstehenden Urlaubs";
$lang["add_attachment"] = "Anhang hinzufügen";

$lang["hidden_topbar_menus"] = "Versteckte Topbar-Menüs";

$lang["make_previous_items_sub_menu"] = "Untermenü des vorherigen Elements erstellen/entfernen";
$lang["add_menu_item"] = "Menüpunkt hinzufügen";
$lang["url"] = "URL";

$lang["show_theme_color_changer"] = "Thema Farbwechsler anzeigen";
$lang["default_theme_color"] = "Default-Designfarbe";
$lang["left_menu"] = "Linkes Menü";
$lang["client_assigned_contacts"] = "Zugewiesene Kundenkontakte";
$lang["timesheet_settings"] = "Arbeitszeittabellen einstellungen";
$lang["users_can_start_multiple_timers_at_a_time"] = "Benutzer können mehrere Timer gleichzeitig starten";

$lang["delete_expenses_category"] = "Ausgabenkategorie löschen";

/* Version 2.5 */

$lang["code_reference"] = "Code-Referenz";

$lang["commit_url"] = "Commit URL";
$lang["new_commits"] = "Neue Commits";
$lang["new_commit"] = "Neues Commit";
$lang["pushed_by"] = "Geschoben von";
$lang["committed_by"] = "Begangen von";
$lang["add_webhook_in_your_repository_at"] = "Fügen Sie einen Webhook in Ihr Repository ein: ";
$lang["webhook_listener_link"] = "Webhook-Listener-Link";
$lang["enable_bitbucket_commit_logs_in_tasks"] = "Aktivieren Sie Bitbucket-Commit-Protokolle in Aufgaben";
$lang["bitbucket_info_text"] = "Um die Commits mit Aufgaben zu verknüpfen, sollten am Ende jeder Commit-Nachricht ein # und eine Task-ID stehen. Beispiel: Dies ist ein Commit von Aufgabe #10.";

$lang["bitbucket_push_received"] = "Bitbucket-Benachrichtigung erhalten";
$lang["notification_bitbucket_push_received"] = "Bitbucket-Benachrichtigung erhalten.";

$lang["hour_log_time_error_message"] = "Bitte geben Sie die Stunde(n) im richtigen Format ein.";
$lang["set_message_permissions"] = "Legen Sie die Nachrichtenberechtigungen fest";
$lang["cant_send_any_messages"] = "Kann keine irgendein Nachrichten senden";
$lang["can_send_messages_to_specific_members_or_teams"] = "Kann Nachrichten an bestimmte Mitglieder oder Teams senden:";

$lang["embed"] = "Einbetten";
$lang["copy"] = "Kopieren";

$lang["estimate_prefix"] = "Präfix Schätzung";

$lang["likes"] = "Likes";

$lang["pusher"] = "Pusher";
$lang["enable_chat_via_pusher"] = "Aktivieren Sie den Chat über Pusher";

$lang["tasks_list"] = "Aufgaben-Liste";
$lang["tasks_kanban"] = "Aufgaben Kanban";
$lang["set_project_tab_order"] = "Legen Sie die Reihenfolge der Projektregisterkarten fest";
$lang["project_tab_order"] = "Reihenfolge der Registerkarte Projekt";
$lang["project_tab_order_help_message"] = "Bitte beachten Sie, dass diese Registerkarten gemäß den Berechtigungen des Benutzers angezeigt werden.";
$lang["project_tab_order_help_message_of_client"] = "Bitte beachten Sie, dass diese Registerkarten gemäß den Berechtigungen des Kundenkontakts angezeigt werden.";
$lang["client_projects"] = "Projekte";

$lang["ticket_assigned"] = "Ticket zugewiesen";
$lang["notification_ticket_assigned"] = "Ticket zugewiesen an %s";

$lang["disable_access_favorite_project_option_for_clients"] = "Deaktivieren Sie Zugang Lieblingsprojekt Option für Kunden";
$lang["disable_editing_left_menu_by_clients"] = "Deaktivieren Sie die Bearbeitung des linken Menüs durch Clients";
$lang["disable_topbar_menu_customization"] = "Deaktivieren Sie die Anpassung des Topbar-Menüs";
$lang["disable_dashboard_customization_by_clients"] = "Deaktivieren Sie die Dashboard-Anpassung durch Clients";

$lang["task_start_date"] = "Startdatum der Aufgabe";
$lang["project_start_date"] = "Projektstartdatum";
$lang["show_on_kanban_card"] = "Auf Kanban-Karte anzeigen";

$lang["original_expense"] = "Anschaffungskosten";
$lang["expense_details"] = "Kostenangaben";

$lang["read_only"] = "Schreibgeschützt";

$lang["internal_use_only"] = "Nur für den internen Gebrauch";
$lang["visible_to_team_members_only"] = "Nur für Teammitglieder sichtbar";
$lang["visible_to_clients_only"] = "Nur für Kunden sichtbar";

$lang["open_in_new_tab"] = "In neuem Tab öffnen";

$lang["client_can_delete_own_files_in_project"] = "Client können eigene Dateien im Projekt löschen";

$lang["enable_slack"] = "Enable slack";
$lang["get_the_webhook_url_of_your_app_from_here"] = "Hier können Sie die Webhook-URL Ihrer App abrufen:";
$lang["slack_webhook_url"] = "Webhook-URL";
$lang["send_a_test_message"] = "Senden Sie eine Testnachricht";
$lang["notification_test_slack_notification"] = "Dies ist eine Demo-Nachricht.";
$lang["slack_notification_error_message"] = "Error! Über die Anmeldeinformationen kann keine Verbindung zum Slack hergestellt werden.";
$lang["dont_send_any_project_related_notifications_to_this_channel"] = "Senden Sie keine projektbezogenen Benachrichtigungen an diesen Kanal";
$lang["save_and_send_a_test_message"] = "Speichern und senden Sie eine Testnachricht";

$lang["copy_sub_tasks"] = "Unteraufgaben kopieren";

$lang["can_update_only_assigned_tasks_status"] = "Kann nur den Status der zugewiesenen Aufgaben aktualisieren";

$lang["import_leads"] = "Interessenten importieren";
$lang["import_lead_error_contact_name"] = "Der Vor- und Nachname des Kontakts ist erforderlich, um einen Interessenten-Kontakt hinzuzufügen.";

$lang["deadline_must_be_equal_or_greater_than_start_date"] = "Frist muss gleich oder größer als Startdatum sein.";

$lang["enable_github_commit_logs_in_tasks"] = "Aktivieren Sie Github-Commit-Protokolle in Aufgaben";
$lang["github_push_received"] = "GitHub-Benachrichtigung erhalten";
$lang["notification_github_push_received"] = "GitHub-Benachrichtigung erhalten.";

$lang["invalid_calendar_id_error_message"] = "Diese Kalender-ID ist ungültig oder Sie haben keine Berechtigung, auf diesen Kalender zuzugreifen";
$lang["total_clients"] = "Kunden insgesamt";
$lang["total_contacts"] = "Kontakte insgesamt";

$lang["message_sending_error_message"] = "Dieser Benutzer hat keine Berechtigung, eine Nachricht an Sie zu senden. Deshalb können Sie auch keine Nachricht senden!";

$lang["days_view"] = "Tagesansicht";
$lang["weeks_view"] = "Wochenansicht";
$lang["months_view"] = "Monatsansicht";

$lang["move_all_tasks_to_to_do"] = "Verschieben Sie alle Aufgaben nach zu Zu Tun";

$lang["started"] = "Gestartet";

$lang["weekends"] = "Wochenenden";

$lang["invited_client_contact_signed_up"] = "Eingeladener Kundenkontakt angemeldet";
$lang["notification_invited_client_contact_signed_up"] = "Eingeladener Kundenkontakt angemeldet.";

$lang["ticket_templates"] = "Ticketvorlagen";
$lang["ticket_template"] = "Ticketvorlage";
$lang["tickets_list"] = "Tickets Liste";
$lang["add_template"] = "Vorlage hinzufügen";
$lang["edit_template"] = "Vorlage bearbeiten";
$lang["insert_template"] = "Vorlage einfügen";
$lang["private_template"] = "Private Vorlage";

$lang["requested_by"] = "Angefordert von";

$lang["create_new_projects_automatically_when_estimates_gets_accepted"] = "Erstellen Sie neue Projekte automatisch, wenn Schätzungen akzeptiert werden";

$lang["typing"] = "Maschinenschreiben";

$lang["new_client_greetings"] = "Neue Kundengrüße";

$lang["timeline_post_commented"] = "Timeline-Beitrag kommentiert";
$lang["post_creator"] = "Post-Ersteller";
$lang["notification_timeline_post_commented"] = "Kommentar zu einem Beitrag.";
$lang["created_a_new_post"] = "Erstellt einen neuen Beitrag";
$lang["notification_created_a_new_post"] = "Erstellt einen neuen Beitrag.";

$lang["verify_email_before_client_signup"] = "Überprüfen Sie die E-Mail-Adresse vor der Client-Anmeldung";
$lang["input_your_email"] = "Geben Sie Ihre E-Mail-Adresse ein";
$lang["verify_email"] = "Client-E-Mail-Überprüfung";
$lang["please_continue_your_signup_process"] = "Bitte setzen Sie Ihren Anmeldevorgang fort.";
$lang["get_started"] = "Loslegen";

$lang["manage_labels"] = "Beschriftungen verwalten";

$lang["timesheet"] = "Arbeitszeittabelle";
$lang["users_can_input_only_total_hours_instead_of_period"] = "Benutzer können nur die Gesamtstunden anstelle des Zeitraums eingeben";
$lang["timesheet_hour_input_help_message"] = "Beispiel: 1h 20m";

$lang["template"] = "Vorlage";
$lang["template_details"] = "Vorlagen details";

$lang["label_existing_error_message"] = "Dieses Etikett wird bereits verwendet. Es kann nicht gelöscht werden.";

/* Version 2.6 */

$lang["paytm_checksum_hash_error_message"] = "Checksum Hash konnte mit Ihren Anmeldeinformationen nicht generiert werden.";

$lang["testing_environment"] = "Testen Umgebung";

$lang["auto_reply_to_tickets"] = "Automatische Antwort auf Tickets";

$lang["total_time_logged"] = "Gesamtzeit protokolliert";
$lang["total_duration"] = "Gesamt des Dauer";

$lang["please_upload_valid_image_files"] = "Bitte laden Sie gültige Bilddateien hoch.";
$lang["upload_image"] = "Bild hochladen";
$lang["item_details"] = "Artikeldetails";
$lang["item_image_sorting_help_message"] = "Das erste Bild ist das Standardbild.";
$lang["show_in_client_portal"] = "Im Kundenportal anzeigen";
$lang["showing_in_client_portal"] = "Im Kundenportal anzeigen";
$lang["add_to_cart"] = "In den Warenkorb legen";
$lang["item_empty_message"] = "Keine Elemente gefunden!";

$lang["order"] = "Bestellung";
$lang["orders"] = "Bestellungen";
$lang["no_items_text"] = "Sie haben keine Artikel in Ihrem Warenkorb!";
$lang["process_order"] = "Prozessauftrag";
$lang["place_order"] = "Bestellung aufgeben";
$lang["edit_item"] = "Element bearbeiten";
$lang["store"] = "Geschäft";
$lang["client_can_access_store"] = "Client kann auf Geschäft zugreifen?";
$lang["added_to_cart"] = "In den Warenkorb gelegt";
$lang["can_access_orders"] = "Kann auf Bestellungen zugreifen?";

$lang["order_settings"] = "Bestelleinstellungen";
$lang["order_logo"] = "Logo bestellen";
$lang["order_prefix"] = "Bestellpräfix";
$lang["order_color"] = "Bestellfarbe";
$lang["initial_number_of_the_order"] = "Anfangsnummer der Bestellung";
$lang["the_orders_id_must_be_larger_then_last_order_id"] = "Die Bestellnummer muss größer sein als die letzte Bestellnummer.";
$lang["order_footer"] = "Fußzeile bestellen";

$lang["order_status"] = "Bestellstatus";
$lang["edit_order_status"] = "Auftragsstatus bearbeiten";
$lang["add_order_status"] = "Bestellstatus hinzufügen";
$lang["delete_order_status"] = "Löschen Auftragsstatus";
$lang["there_has_orders_with_this_status"] = "Es gibt Bestellungen mit diesem Status";
$lang["orders_list"] = "Bestellliste";
$lang["sales"] = "Umsatz";
$lang["order_date"] = "Bestelldatum";
$lang["edit_order"] = "Reihenfolge bearbeiten";
$lang["delete_order"] = "Bestellung löschen";
$lang["show_in_order"] = "In der Reihenfolge anzeigen";
$lang["order_preview"] = "Bestellvorschau";
$lang["order_from"] = "Bestellung von";
$lang["add_order"] = "Bestellung hinzufügen";

$lang["process_order_info_message"] = "Sie sind dabei, die Bestellung zu erstellen. Bitte überprüfen Sie die Details vor dem Absenden.";

$lang["order_creator_contact"] = "Bestellen Schöpfer Kontakt";

$lang["create_estimate"] = "Schätzung erstellen";
$lang["include_all_items_of_this_order"] = "Alle Artikel dieser Bestellung einschließen";

$lang["new_order_received"] = "Neue Bestellung erhalten";
$lang["notification_new_order_received"] = "Neue Bestellung erhalten.";

$lang["order_status_updated"] = "Bestellstatus aktualisiert";
$lang["notification_order_status_updated"] = "Der Bestellstatus wurde aktualisiert.";

$lang["add_more_items"] = "Weitere Elemente hinzufügen";

$lang["yes_only_own_leads"] = "Ja, nur eigene Interessenten";
$lang["yes_all_leads"] = "Ja, alle Interessenten";

$lang["yes_only_own_clients"] = "Ja, nur eigene Kunden";
$lang["yes_all_clients"] = "Ja, alle Kunden";

$lang["recently_updated"] = "Kürzlich aktualisiert";
$lang["recently_moved_to"] = "Kürzlich umgezogen nach";

$lang["recently_commented"] = "Kürzlich kommentiert";
$lang["mentioned_me"] = "Erwähnte mich";
$lang["recently_mentioned_me"] = "Kürzlich erwähnte mich";
$lang["in"] = "Im";
$lang["recently_meaning"] = "Kürzlich Bedeutung";

$lang["quick_filters"] = "Schnelle Filter";

$lang["has_open_projects"] = "Hat offene Projekte";
$lang["has_completed_projects"] = "Hat Projekte abgeschlossen";
$lang["has_any_hold_projects"] = "Hat irgendwelche Halteprojekte";

$lang["has_unpaid_invoices"] = "Hat unbezahlte Rechnungen";
$lang["has_overdue_invoices"] = "Hat überfällige Rechnungen";
$lang["has_partially_paid_invoices"] = "Hat teilweise Rechnungen bezahlt";
$lang["assignee"] = "Zessionar";

$lang["upload_and_crop"] = "Hochladen und zuschneiden";

$lang["active_members_on_projects"] = "Aktive Mitglieder bei Projekten";

/* Version 2.6.1 */

$lang["open_tickets_list"] = "Ticketsliste öffnen";

$lang["login_attempt_failed"] = "Anmeldeversuch fehlgeschlagen";
$lang["profile_image_error_message"] = "Das Bild sollte 200x200px groß sein.";

$lang["re_captcha_info_text"] = "Öffnen Sie vor dem Abmelden einen neuen Browser und stellen Sie sicher, dass reCaptcha funktioniert.";
$lang["yes_assigned_tickets_only"] = "Ja, nur zugewiesene Tickets";
$lang["no_such_custom_field_found"] = "Kein solches benutzerdefiniertes Feld gefunden.";
$lang["open_in_google_calendar"] = "Im Google Kalender öffnen";

$lang["enable_embedded_form_to_get_tickets"] = "Aktivieren Sie das eingebettete Formular, um Tickets zu erhalten";
$lang["submit_your_request"] = "Senden Sie Ihre Anfrage";
$lang["submit"] = "einreichen";
$lang["ticket_submission_message"] = "Ihr Ticket wurde erfolgreich eingereicht!";
$lang["your_email"] = "Deine E-Mail";
$lang["your_name"] = "Dein Name";

$lang["item_categories"] = "Artikelkategorien";
$lang["edit_items_category"] = "Elemente bearbeiten Kategorie";
$lang["delete_items_category"] = "Artikelkategorie löschen";

$lang["create_recurring_tasks_before"] = "Erstellen wiederkehrende Aufgaben vor";
$lang["create_new_order"] = "Create new order";
$lang["find_more_items"] = "Find more items";

/* Version 2.8 */

$lang["reports"] = "Reports";

$lang["yes_all_estimates"] = "Ja, alle Schätzungen";
$lang["yes_only_own_estimates"] = "Ja, nur bei Schätzungen";

$lang["add_category"] = "Add category";
$lang["edit_category"] = "Edit category";
$lang["delete_category"] = "Delete category";

$lang["proposal"] = "Angebot";
$lang["proposals"] = "Angebote";
$lang["can_access_proposals"] = "Kann auf Angebote zugreifen";
$lang["show_in_proposal"] = "Zeige in Angebot";
$lang["proposal_date"] = "Angebots-Datum";
$lang["edit_proposal"] = "Angebot bearbeiten";
$lang["delete_proposal"] = "Angebot löschen";
$lang["proposal_sent_message"] = "das Angebot wurde gesendet!";
$lang["add_proposal"] = "Angebot hinzufügen";
$lang["proposal_preview"] = "Angebot Vorschau";
$lang["clone_proposal"] = "Angebot klonen";
$lang["proposal_to"] = "Angebot für";
$lang["proposal_settings"] = "Einstellungen Angebot";
$lang["proposal_prefix"] = "Angebot Präfix";
$lang["proposal_color"] = "Angebot Farbe";
$lang["send_proposal_bcc_to"] = "Bei Angebotsversand an Kunden sende BCC an";
$lang["initial_number_of_the_proposal"] = "Start-Nummer für Angebote";
$lang["the_proposals_id_must_be_larger_then_last_proposal_id"] = "Die ID des Vorschlags muss größer sein als die ID des letzten Vorschlags..";
$lang["proposal_sent"] = "Angebot gesendet";
$lang["notification_proposal_sent"] = "Angebot senden";
$lang["proposal_accepted"] = "Angebot akzeptiert";
$lang["notification_proposal_accepted"] = "Angebot akzeptieren";
$lang["proposal_rejected"] = "Angebot abgelehnt";
$lang["notification_proposal_rejected"] = "Angebot abgelehnt";
$lang["create_estimate"] = "Erstelle Schätzung";
$lang["include_all_items_of_this_proposal"] = "Alle Punkte des Angebots einschließen";
$lang["proposal_view"] = "Ansicht Angebot";
$lang["accept_proposal"] = "Angebot akzeptieren";
$lang["reject_proposal"] = "Angebot ablehnen";
$lang["proposal_accepted_message"] = "Sie haben diesen Vorschlag erfolgreich angenommen!";

$lang["set_timeline_permissions"] = "Berechtigungen für die Zeitleiste festlegen";
$lang["cant_see_the_timeline"] = "Kann die Zeitleiste nicht sehen";
$lang["can_see_timeline_posts_from_specific_members_or_teams"] = "Kann Beiträge von bestimmten Mitgliedern oder Teams in der Zeitleiste sehen:";

$lang["localization"] = "Lokalisierung";
$lang["localization_settings"] = "Lokalisierungs-Einstellungen";
$lang["main_task"] = "Hauptaufgabe";

$lang["select_all"] = "Alles auswählen";
$lang["unselect_all"] = "Alles abwählen";

$lang["plugins"] = "Plugins";
$lang["install_plugin"] = "Installiere Plugin";
$lang["please_upload_a_zip_file"] = "Bitte lade eine .zip-Datei hoch.";
$lang["install"] = "Installieren";
$lang["installed"] = "Installiert";
$lang["activate"] = "Aktiveren";
$lang["activated"] = "Aktiviert";
$lang["deactivate"] = "Deaktivieren";
$lang["deactivated"] = "Deaktiviert";
$lang["the_required_files_missing"] = "Die notwendigen Dateien fehlen";
$lang["this_plugin_is_already_installed"] = "Das Plugin ist bereits installiert.";
$lang["version"] = "Version";
$lang["by"] = "Von";
$lang["visit_plugin_site"] = "Besuche die Plugin-Seite";

$lang["can_manage_team_members_job_information"] = "Kann Informationen über die Aufgaben der Teammitglieder verwalten?";

$lang["add_filter"] = "Filter hinzufügen";
$lang["specific_client_groups"] = "Besondere Kundengruppen";
$lang["choose_client_groups"] = "Wähle Kundengruppen";

$lang["checklist_template"] = "Checklisten-Vorlage";
$lang["add_checklist_template"] = "Füge Checklisten-Vorlage hinzu";
$lang["edit_checklist_template"] = "Bearbeite Checklisten-Vorlage";
$lang["delete_checklist_template"] = "Lösche Checklisten-Vorlage";
$lang["select_from_template"] = "Wähle aus Vorlage";
$lang["type_new_item"] = "Neuen Artikel eingeben";

$lang["conversion_rate"] = "Umrechnungskurs";

$lang["all_tasks"] = "Alle Aufgaben";
$lang["user_roles"] = "Benutzerrollen";
$lang["edit_user_role"] = "Benutzerrollen bearbeiten";

$lang["total_leads"] = "Alle Interessenten";

$lang["copy_link"] = "Link kopieren";
$lang["copy_comment_link"] = "Link zum Kommentar kopieren";

$lang["pin_comment"] = "Kommentar anheften";
$lang["unpin_comment"] = "Kommentar lösen";
$lang["pinned_comments"] = "Angeheftete Kommentare";

$lang["reply_from_this_comment"] = "Antwort auf den Kommentar <br />";

$lang["project_files"] = "Projekt-Dateien";
$lang["edit_files"] = "Bearbeite Dateien";

$lang["invoice_manual_payment_added"] = "Manuelle Zahlung von Rechnungen hinzugefügt";
$lang["notification_invoice_manual_payment_added"] = "Manuelle Zahlung hinzugefügt.";

$lang["save_as_note"] = "Speichern als Notiz";
$lang["client_will_not_see_any_notes"] = "Kunde kann die Notizen nicht sehen.";

$lang["prospects"] = "Aussichten";
$lang["estimate_forms"] = "Formulare Schätzung";

$lang["proposal_editor"] = "Angebots-Editor";
$lang["proposal_templates"] = "Angebots-Vorlagen";
$lang["add_proposal_template"] = "Angebots-Vorlage hinzufügen";
$lang["edit_proposal_template"] = "Angebots-Vorlage bearbeiten";
$lang["delete_proposal_template"] = "Angebots-Vorlage löschen";
$lang["use_template_from"] = "Benutze Vorlage von";
$lang["print_proposal"] = "Angebot drucken";
$lang["proposal_template_inserting_instruction"] = "Wenn Sie eine Vorlage einfügen, gehen alle nicht gespeicherten Änderungen verloren.";

$lang["default"] = "Voreinstellung";

$lang["encryption"] = "Verschlüsselung";
$lang["imap_encryption_help_message"] = "Verschiedene Server können mit unterschiedlichen Konfigurationen arbeiten. Wenn Sie Probleme bei der Verbindung mit IMAP haben, prüfen Sie bitte verschiedene Optionen.";

$lang["administration_permissions"] = "Administrative Rechte";
$lang["can_manage_all_kinds_of_settings"] = "Kann alle Arten von Einstellungen vornehmen";
$lang["can_manage_user_role_and_permissions"] = "Kann Benutzerrollen und Rechte verwalten";
$lang["can_add_or_invite_new_team_members"] = "Kann Mitglieder einladen und hinzufügen";

$lang["add_signature_option_on_accepting_proposal"] = "Unterschriftsoption bei der Annahme von Vorschlägen hinzufügen";
$lang["accept"] = "Akzeptieren";
$lang["signer_info"] = "Unterzeichner-Information";
$lang["default_template"] = "Standard-Vorlage";
$lang["change_template"] = "Vorlage ändern";
$lang["this_variable_is_unsupported"] = "Diese Variable wird nicht unterstützt.";

$lang["plugin_deletion_alert_message"] = "Alle Einträge und Dateien werden ebenfalls gelöscht!";
$lang["plugin_requires_at_least_error_message"] = "Dieses Plugin benötigt mindestens die Version %s .";
$lang["plugin_supports_at_most_error_message"] = "Dieses Plugin unterstützt höchstens die Version %s.";
$lang["no_update_hook_found"] = "Kein Update-Aufhänger gefunden!";
$lang["indexed"] = "Indexiert";

$lang["save_and_continue"] = "Speichern und fortfahren";
$lang["add_new_project_member"] = "Füge ein neues Projekt-Mitglied hinzu";

$lang["field_type_time"] = "Zeit";
$lang["client_can_assign_tasks"] = "Kunde kann Aufgaben zuweisen?";
$lang["can_create_lead_from_public_form"] = "Kann Interessent aus öffentlichen Formularen erzeugen";
$lang["lead_html_form_code"] = "HTML-Formularcode für die Erstellung von Interessenten";

$lang["enable_comments_on_estimates"] = "Ermögliche Kommentare für Schätzungen";
$lang["show_most_recent_estimate_comments_at_the_top"] = "Die neuesten Kommentare zu Schätzungen oben anzeigen";
$lang["estimate_commented"] = "Schätzung kommentiert";
$lang["estimate_creator"] = "Ersteller der Schätzung";
$lang["notification_estimate_commented"] = "Kommentar zu einer Schätzung.";

$lang["contacts_logged_in_today"] = "Kontakte haben sich heute eingeloggt";
$lang["contacts_logged_in_last_seven_days"] = "Kontakte haben sich in den letzte sieben Tagen eingewählt.";

$lang["clients_has_unpaid_invoices"] = "Kunde hat unbezahlte Rechnungen";
$lang["clients_has_partially_paid_invoices"] = "Kunde hat teilweise bezahlte Rechnungen";
$lang["clients_has_overdue_invoices"] = "Kunde hat überfällige Rechnungen";

$lang["of_total_clients"] = "von allen Kunden";

$lang["has_canceled_projects"] = "Hat Projekt abgebrochen";
$lang["clients_has_open_projects"] = "Kunde hat offene Projekte";
$lang["clients_has_hold_projects"] = "Kunde hart wartende Projekte";
$lang["clients_has_completed_projects"] = "Kunde hat abgeschlossene Projekte";
$lang["clients_has_canceled_projects"] = "Kunde hat abgebrochene Projekte";

$lang["has_open_estimates"] = "Hat offene Schätzungen";
$lang["has_accepted_estimates"] = "Hat Schätzungen akzeptiert";
$lang["has_new_estimate_requests"] = "Hat neue Schätzungs-Anfragen";
$lang["has_estimate_requests_in_progress"] = "Hat Anfragen für Kostenvoranschläge in Bearbeitung";
$lang["clients_has_open_estimates"] = "Kunde hat öffene Schätzungen";
$lang["clients_has_accepted_estimates"] = "Kunde hat Schätzungen akzeptiert";
$lang["clients_has_new_estimate_requests"] = "Kunde hat neue Anfragen für Schätzungen";
$lang["clients_has_estimate_requests_in_progress"] = "Kunde hat offene Schätzungen in Bearbeitung";

$lang["has_open_tickets"] = "Hat offene Tickets";
$lang["clients_has_open_tickets"] = "Kunde hat offene Tickets";

$lang["has_new_orders"] = "Hat neue Aufträge";
$lang["clients_has_new_orders"] = "Kunde hat neue Aufträge";

$lang["has_open_proposals"] = "Hat offene Angebote";
$lang["has_accepted_proposals"] = "Hat akzeptierte Angebote";
$lang["has_rejected_proposals"] = "Hat abgelehnte Angebote";
$lang["clients_has_open_proposals"] = "Kunde hat offene Angebote";
$lang["clients_has_accepted_proposals"] = "Kunde hat akzeptierte Angebote";
$lang["clients_has_rejected_proposals"] = "Kunde hat abgelehnte Angebote";

$lang["logged_in_today"] = "Heute angemeldet";
$lang["logged_in_last_seven_days"] = "Angemeldet in den letzten 7 Tagen";

$lang["hide_from_kanban_view"] = "Aus der Kanban-Ansicht ausblenden";

/* Version 2.9 */

$lang["contract"] = "Vertrag";
$lang["contracts"] = "Verträge";
$lang["can_access_contracts"] = "Kann auf Verträge zugreifen";
$lang["show_in_contract"] = "Zeige in Vertrag";
$lang["contract_date"] = "Vertrags-Datum";
$lang["edit_contract"] = "Vertrag bearbeiten";
$lang["delete_contract"] = "Vertrag löschen";
$lang["contract_sent_message"] = "Der Vertrag wurde gesendet!";
$lang["add_contract"] = "Vertrag hinzufügen";
$lang["contract_preview"] = "Vertrags-Voransicht";
$lang["clone_contract"] = "Vertrag kopieren";
$lang["contract_to"] = "Vertrag für";
$lang["contract_settings"] = "Vertrags-Einstellungen";
$lang["contract_color"] = "Farbe Vertrag";
$lang["send_contract_bcc_to"] = "Wenn ein Vertrag an den Kunden gesendet wird, sende BCC an";
$lang["initial_number_of_the_contract"] = "Start-Nummer des Vertrages";
$lang["the_contracts_id_must_be_larger_then_last_contract_id"] = "Die ID des Vertrages muss höher sein als die letzte verwendete ID.";
$lang["contract_sent"] = "Vertrag gesendet";
$lang["notification_contract_sent"] = "Sende einen Vertrag";
$lang["contract_accepted"] = "Vertrag akzeptiert";
$lang["notification_contract_accepted"] = "Vertrag akzeptiert";
$lang["contract_rejected"] = "Vertrag abgelehnt";
$lang["notification_contract_rejected"] = "Vertrag abgelehnt";
$lang["create_estimate"] = "Erstelle Schätzung";
$lang["include_all_items_of_this_contract"] = "Umfassen Sie alle Punkte dieses Vertrags";
$lang["contract_view"] = "Ansicht Vertrag";
$lang["accept_contract"] = "Vertrag akzeptieren";
$lang["reject_contract"] = "Vertrag ablehnen";
$lang["contract_accepted_message"] = "Sie haben den Vertrag akzeptiert!";

$lang["contract_editor"] = "Vertrags-Editor";
$lang["contract_templates"] = "Vertrags-Vorlage";
$lang["add_contract_template"] = "Vertrags-Vorlage hinzufügen";
$lang["edit_contract_template"] = "Vertrags-Vorlage bearbeiten";
$lang["delete_contract_template"] = "Vertrags-Vorlage löschen";
$lang["use_template_from"] = "Verwende Vorlage von";
$lang["print_contract"] = "Drucke Vertrag";
$lang["contract_template_inserting_instruction"] = "Sie verlieren alle ungespeicherten Änderungen bei Verwendung einer neuen Vorlage!";

$lang["ticket_info"] = "Ticket-Info";

$lang["recurring_tasks"] = "Wiederholende Aufgabe";
$lang["add_multiple_contacts"] = "Füge mehrere Kontakte hinzu";

$lang["total_invoiced"] = "Gesamt berechnet";

$lang["show_sub_tasks"] = "Zeige Unteraufgaben";

$lang["add_signature_option_on_accepting_estimate"] = "Unterschriftsoption bei der Annahme des Kostenvoranschlags hinzufügen";
$lang["accept_estimate"] = "Akzeptiere Schätzung";

$lang["sub_tasks_completed"] = "Unter-Aufgaben abgeschloss";

$lang["client_portal"] = "Kundenportal";
$lang["sales_and_prospects"] = "Verkäufe und Aussichten";

$lang["contract_prefix"] = "Vertrags-Präfix";
$lang["default_contract_template"] = "Standard-Veretrags-Vorlage";

$lang["default_proposal_template"] = "Standard-Angebots-Vorlage";

$lang["signed_date"] = "Unterzeichnetes Datum";

$lang["add_signature_option_on_accepting_contract"] = "Unterschriftsoption bei der Vertragsannahme hinzufügen";
$lang["accept"] = "Akzeptiert";
$lang["signer_info"] = "Unterzeichner-Information";
$lang["default_template"] = "Standard-Vorlage";
$lang["change_template"] = "Vorlage ändern";

/* Version 2.9.2 */

$lang["custom_left_menu_instruction"] = "Für externe Links fügen Sie bitte http oder https vor der URL ein.";
$lang["parent_task_completing_error_message"] = "Es gibt unvollständige Teilaufgabe(n) zu dieser Aufgabe!";

/* Version 3.0 */

$lang["was_this_article_helpful"] = "War dieser Artikel hilfreich?";
$lang["thank_you_for_your_feedback"] = "Danke für Ihre Rückmeldung";
$lang["feedback"] = "Rückmeldung";

$lang["add_signature_option_for_team_members"] = "Signaturoption für Teammitglieder hinzufügen";
$lang["sign_contract"] = "Vertrag unterschreiben";

$lang["remove_task_statuses"] = "Aufgabenzustände entfernen";
$lang["task_statuses"] = "Status der Aufgabe";

$lang["file_delete_permission_error_message"] = "Wir können einige Dateien nicht löschen, da Sie keine Berechtigung haben.";

$lang["reject_estimate"] = "Schätzung ablehnen";

$lang["unknown_user"] = "Unbekannter Benutzer";

$lang["yes_specific_client_groups"] = "Ja, bestimmte Kundengruppen";

/* Version 3.1 */

$lang["add_company"] = "Firma hinzufügen";
$lang["edit_company"] = "Firma bearbeiten";
$lang["delete_company"] = "Unternehmen löschen";
$lang["default_company"] = "Standardfirma";

$lang["task_priority"] = "Aufgabenpriorität";
$lang["priority"] = "Priorität";
$lang["add_task_priority"] = "Aufgabenpriorität hinzufügen";
$lang["edit_task_priority"] = "Aufgabenpriorität bearbeiten";
$lang["delete_task_priority"] = "Aufgabenpriorität löschen";

$lang["import_items"] = "Elemente importieren";
$lang["import_error_field_required"] = "%s-Feld ist erforderlich";

$lang["do_not_show_projects"] = "Projekte nicht anzeigen";

$lang["show_in_kanban"] = "Im Kanban anzeigen";
$lang["project_name"] = "Projektname";
$lang["client_name"] = "Kundenname";

$lang["import_date_error_message"] = "Datumsformat ist ungültig.";

$lang["event_label"] = "Ereignisbezeichnung";

$lang["undo"] = "Rückgängig machen";

$lang["clone_expense"] = "Ausgabe klonen";
$lang["files_will_not_be_copied"] = "Dateien werden nicht kopiert.";

$lang["checklist_group"] = "Checklistengruppe";
$lang["checklists"] = "Checklisten";
$lang["add_checklist_group"] = "Checklistengruppe hinzufügen";
$lang["edit_checklist_group"] = "Checklistengruppe bearbeiten";
$lang["delete_checklist_group"] = "Checklistengruppe löschen";
$lang["select_from_checklist_group"] = "Aus Checklistengruppe auswählen";

$lang["import_leaves"] = "Blätter importieren";

$lang["import_tasks"] = "Aufgaben importieren";

$lang["import_not_exists_error_message"] = "%s nicht gefunden.";
$lang["import_task_points_error_message"] = "Punktefeld ist ungültig.";
$lang["user"] = "Benutzer";

$lang["checkout"] = "Zur Kasse";
$lang["all_plugins"] = "Alle Plugins";

$lang["payments_summary"] = "Zahlungszusammenfassung";
$lang["yearly_summary"] = "Jahreszusammenfassung";
$lang["clients_summary"] = "Kundenübersicht";

$lang["import_leave_status_error_message"] = "Status ist ungültig. Gültige Status sind: ";

$lang["import_expense"] = "Ausgaben importieren";

$lang["mark_as_default"] = "Als Standard markieren";
$lang["remove_as_default"] = "Als Standard entfernen";
$lang["staff_default_dashboard_help_message"] = "Dies wird das Standard-Dashboard für alle Teammitglieder ersetzen. Bitte beachten Sie, dass die Widgets gemäß der Erlaubnis des Benutzers verteilt werden.";

/* Version 3.2 */

$lang["reminder"] = "Erinnerung";
$lang["reminders"] = "Erinnerungen";
$lang["show_all_reminders"] = "Alle Erinnerungen anzeigen";
$lang["time"] = "Time";
$lang["add_reminder"] = "Erinnerung hinzufügen";
$lang["delete_reminder"] = "Erinnerung löschen";
$lang["snooze"] = "Snooze";
$lang["dismiss"] = "Dismiss";
$lang["snooze_length"] = "Schlummerlänge";
$lang["minutes"] = "Minuten";
$lang["reminder_sound_volume"] = "Lautstärke des Erinnerungstons";
$lang["reminder_details"] = "Erinnerungsdetails";
$lang["mark_as_done"] = "Als erledigt markieren";
$lang["client_can_create_reminders"] = "Kunde kann Erinnerungen erstellen?";

$lang["php_file_format_is_not_allowed"] = "PHP-Dateiformat ist nicht erlaubt!";

$lang["projects_overview"] = "Projektübersicht";
$lang["progression"] = "Fortschritt";

$lang["this_year"] = "Dieses Jahr";
$lang["last_year"] = "Letztes Jahr";
$lang["last_12_months"] = "Letzte 12 Monate";

$lang["estimate_sent_statistics"] = "Gesendete Statistiken schätzen";

$lang["title_language_key"] = "Sprachschlüssel des Titels";
$lang["placeholder_language_key"] = "Platzhalter-Sprachschlüssel";
$lang["keep_it_blank_if_you_do_not_use_translation"] = "Leer lassen, wenn Sie keine Übersetzung verwenden";
$lang["language_key_recommendation_help_text"] = "Empfohlen, jedes Präfix wie custom_field_ zu verwenden";

$lang["other"] = "Andere";

$lang["print_estimate"] = "Kostenvoranschlag drucken";

$lang["the_person_who_will_manage_this_client"] = "Die Person, die diesen Client verwalten wird.";
$lang["the_person_who_will_manage_this_lead"] = "Die Person, die diesen Lead verwalten wird.";

$lang["language_key"] = "Sprachschlüssel";
$lang["left_menu_language_key_recommendation_help_text"] = "Empfohlen jedes Präfix wie left_menu_ zu verwenden";

$lang["project_type"] = "Projekttyp";
$lang["client_project"] = "Kundenprojekt";
$lang["internal_project"] = "Internes Projekt";

$lang["contact_info"] = "Kontaktinformationen";
$lang["type"] = "Type";
$lang["organization"] = "organization";
$lang["person"] = "Person";

$lang["last_announcement"] = "Letzte Ankündigung";
$lang["no_announcement_yet"] = "Noch keine Ankündigung!";

$lang["team_members_overview"] = "Teammitglieder Übersicht";
$lang["on_leave_today"] = "Heute im Urlaub";

$lang["enable_embedded_form_to_get_leads"] = "Eingebettetes Formular aktivieren, um Leads zu erhalten";
$lang["please_submit_the_form"] = "Bitte senden Sie das Formular ab";
$lang["show_in_embedded_form"] = "In eingebetteter Form anzeigen";

$lang["after_submit"] = "Nach dem Absenden";
$lang["return_json_response"] = "json-Antwort zurückgeben";
$lang["show_text_result"] = "Textergebnis anzeigen";
$lang["redirect_to_this_url"] = "Zu dieser URL weiterleiten:";

$lang["yes_only_own_timelogs"] = "Ja, nur eigene Zeitprotokolle";
$lang["yes_only_own_project_members"] = "Ja, nur eigene Projektmitglieder";
$lang["excluding_his_her_timelogs"] = "Seine/ihre eigenen Zeitprotokolle ausschließen";
$lang["can_add_own_timelogs_only"] = "Kann nur eigene Zeitprotokolle hinzufügen";

$lang["all_tasks_overview"] = "Übersicht aller Aufgaben";

$lang["invoice_overview"] = "Rechnungsübersicht";

$lang["next_reminder"] = "Nächste Erinnerung";

$lang["new_tickets_in_last_30_days"] = "Neue Tickets in den letzten 30 Tagen";

$lang["individual"] = "individuell";

$lang["total_after_discount"] = "Gesamt nach Rabatt";

/* Version 3.3 */

$lang["change_the_tasks_start_date_and_deadline_based_on_project_start_date"] = "Change the tasks start date and deadline based on project start date";

$lang["can_edit_only_own_created_projects"] = "Can edit only own created projects";
$lang["can_delete_only_own_created_projects"] = "Can delete only own created projects";

$lang["checklist_status"] = "Checklist status";

/* Version 3.4 */

$lang["subscribe"] = "Subscribe";
$lang["email_protocol"] = "Email protocol";

$lang["please_enable_the_file_uploads_php_settings"] = "Please enable the file_uploads php setting in the server.";
$lang["file_size_too_large"] = "File size is too large. Please increase the upload_max_filesize from server.";

$lang["sub_task_status"] = "Sub task status";

$lang["can_access_client_feedback_in_projects"] = "Can access client feedback in projects?";
$lang["change_the_milestone_dates_based_on_project_start_date"] = "Change the milestone dates based on project start date";

$lang["send_first_due_invoice_reminder_notification_before"] = "Send 1st due invoice reminder before due date";
$lang["send_second_due_invoice_reminder_notification_before"] = "Send 2nd due invoice reminder before due date";

$lang["send_first_invoice_overdue_reminder_after"] = "Send 1st invoice overdue reminder after";
$lang["send_second_invoice_overdue_reminder_after"] = "Send 2nd invoice overdue reminder after";

$lang["product"] = "Product";

$lang["subscription_id"] = "Subscription ID";
$lang["subscription_sent_message"] = "The subscription has been sent!";
$lang["add_subscription"] = "Add subscription";
$lang["edit_subscription"] = "Edit subscription";
$lang["delete_subscription"] = "Delete subscription";
$lang["subscription"] = "Subscription";
$lang["subscriptions"] = "Subscriptions";
$lang["subscription_value"] = "Subscription Value";
$lang["subscription_items"] = "Subscription items";
$lang["email_subscription_to_client"] = "Email subscription to client";
$lang["send_subscription"] = "Send subscription";
$lang["subscription_settings"] = "Subscription Settings";
$lang["subscription_prefix"] = "Subscription prefix";
$lang["initial_number_of_the_subscription"] = "Initial number of the subscription";
$lang["can_access_subscriptions"] = "Can access subscriptions?";
$lang["show_in_subscription"] = "Show in subscription";
$lang["subscription_total"] = "Subscription total";
$lang["start_subscription"] = "Start subscription";

$lang["subscription_success_message"] = "You're subscription has been started successfully.";

$lang["enable_stripe_subscription"] = "Enable Stripe subscription";
$lang["please_enable_the_stripe_payment_method_first"] = "Please enable the stripe payment method first!";
$lang["tax_mapping"] = "Tax mapping";
$lang["mapped"] = "Mapped";
$lang["select_stripe_tax"] = "Select Stripe tax";
$lang["stripe_price_error_message"] = "App subscription price and recurring interval should be same as stripe product price and interval.";
$lang["stripe_tax_error_message"] = "Some taxes are not mapped with stripe yet. Please map the taxes from the subscription settings.";
$lang["payment_status"] = "Payment status";
$lang["failed"] = "Failed";
$lang["next_billing_date"] = "Next billing date";
$lang["cancel_subscription"] = "Cancel subscription";

$lang["invoice_number"] = "Invoice number";
$lang["estimate_number"] = "Estimate number";
$lang["order_number"] = "Order number";

$lang["client_can_access_notes"] = "Client can access notes?";

$lang["my_tasks_overview"] = "My Tasks Overview";

$lang["leads_overview"] = "Leads Overview";
$lang["converted_to_client"] = "Converted to client";

$lang["remember_to_add_this_urls_in_authorized_redirect_uri"] = "Remember to add this urls in Authorized redirect uri";

$lang["merge"] = "Merge";
$lang["move_all_comments_or_notes_from"] = "Move all comments/notes from";
$lang["moved_to"] = "Moved to";

$lang["ok"] = "OK";
$lang["app"] = "App";
$lang["stripe"] = "Stripe";
$lang["activate_as_stripe_subscription"] = "Activate as Stripe subscription";
$lang["activate_as_internal_subscription"] = "Activate as internal subscription";
$lang["activate_as_stripe_subscription_message_1"] = "Please map the stripe product and price with this subscription. You can add the stripe products and prices from your stripe dashboard.";
$lang["activate_as_stripe_subscription_message_2"] = "The client will get a request to add the payment method with this subscription. Once the client submit the payment method, this subscription will be activated and auto payment will be enabled via stripe.";
$lang["activate_as_internal_subscription_message_1"] = "This subscription will be managed by app. The invoices will be created based on the subscription terms.";
$lang["activate_as_internal_subscription_message_2"] = "Note: Payments will not be done automatically. For automated payment, you can use the stripe subscription.";
$lang["subscription_toatl_can_not_empty_message"] = "Subscription total can't be 0.";

$lang["subscription_request_sent"] = "Subscription request sent";
$lang["notification_subscription_request_sent"] = "New subscription request";

$lang["first_billing_date"] = "First billing date";
$lang["first_billing_date_cant_be_past_message"] = "First billing date can’t be past. Keep it blank to use the date when the client will subscribe.";

$lang["gst_number"] = "GST Number";

$lang["announcement_created"] = "Announcement created";

$lang["company_logo"] = "Company Logo";

$lang["task_commented"] = "Task commented";
$lang["task_assigned"] = "Task assigned";
$lang["task_general"] = "Task general";

return $lang;
