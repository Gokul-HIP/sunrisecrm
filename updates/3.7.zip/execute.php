<?php

try {
    $db = db_connect('default');
    $dbprefix = $db->getPrefix();

    if (!$dbprefix) {
        $dbprefix = "";
    }

    $upgrade_sql = "upgrade-3.7.sql";
    $sql = file_get_contents($upgrade_sql);

    if ($dbprefix) {
        $sql = str_replace('CREATE TABLE IF NOT EXISTS `', 'CREATE TABLE IF NOT EXISTS `' . $dbprefix, $sql);
        $sql = str_replace('INSERT INTO `', 'INSERT INTO `' . $dbprefix, $sql);
        $sql = str_replace('ALTER TABLE `', 'ALTER TABLE `' . $dbprefix, $sql);
        $sql = str_replace('DELETE FROM `', 'DELETE FROM `' . $dbprefix, $sql);
        $sql = str_replace('UPDATE `', 'UPDATE `' . $dbprefix, $sql);
        $sql = str_replace('DROP TABLE `', 'DROP TABLE `' . $dbprefix, $sql);
    }

    foreach (explode(";#", $sql) as $query) {
        $query = trim($query);
        if ($query) {
            try {
                $db->query($query);
            } catch (\Exception $ex) {
                log_message("error", $ex->getTraceAsString());
            }
        }
    }

    unlink($upgrade_sql);



    function update_app_config() {

        $app_config_file = 'app/Config/App.php';
        $app_config_content = file_get_contents($app_config_file);

        //ProxyIPs value should be an array
        $app_config_content = str_replace("public \$proxyIPs = '';", "public \$proxyIPs = [];", $app_config_content);


        //Comment out the permittedURIChars if already exists.
        $app_config_content = str_replace('public $permittedURIChars', '//public $permittedURIChars', $app_config_content);

        // Define the new variable to add after $uriProtocol
        $pattern = '/(public\s+\$uriProtocol\s*=\s*\'[^\']*\';)/';


        $new_variable = "   public \$permittedURIChars = 'a-z 0-9~%.:_\\-';\n\n";

        //check if the allowedHostnames is already defined. If not, add it.
        if (strpos($app_config_content, '$allowedHostnames') === false) {
            $new_variable = "   public \$permittedURIChars = 'a-z 0-9~%.:_\\-';\n\n   public \$allowedHostnames = [];\n\n";
        }

        $app_config_content = preg_replace($pattern, "$1\n\n\n$new_variable", $app_config_content);

        //Comment out /remove unnecessary configs. 
        $app_config_content = str_replace('$this->set_cookie_domain();', '', $app_config_content);
        $app_config_content = str_replace('public $sessionDriver', '//public $sessionDriver', $app_config_content);
        $app_config_content = str_replace('public $sessionCookieName', '//public $sessionCookieName', $app_config_content);
        $app_config_content = str_replace('public $sessionExpiration', '//public $sessionExpiration', $app_config_content);
        $app_config_content = str_replace('public $sessionSavePath', '//public $sessionSavePath', $app_config_content);
        $app_config_content = str_replace('public $sessionMatchIP', '//public $sessionMatchIP', $app_config_content);
        $app_config_content = str_replace('public $sessionTimeToUpdate', '//public $sessionTimeToUpdate', $app_config_content);
        $app_config_content = str_replace('public $sessionRegenerateDestroy', '//public $sessionRegenerateDestroy', $app_config_content);
        $app_config_content = str_replace('public $cookiePrefix', '//public $cookiePrefix', $app_config_content);
        $app_config_content = str_replace('public $cookieDomain', '//public $cookieDomain', $app_config_content);
        $app_config_content = str_replace('public $cookiePath', '//public $cookiePath', $app_config_content);
        $app_config_content = str_replace('public $cookieSecure', '//public $cookieSecure', $app_config_content);
        $app_config_content = str_replace('public $cookieHTTPOnly', '//public $cookieHTTPOnly', $app_config_content);
        $app_config_content = str_replace('public $cookieSameSite', '//public $cookieSameSite', $app_config_content);

        $app_config_content = str_replace('public $CSRFTokenName', '//public $CSRFTokenName', $app_config_content);
        $app_config_content = str_replace('public $CSRFHeaderName', '//public $CSRFHeaderName', $app_config_content);
        $app_config_content = str_replace('public $CSRFCookieName', '//public $CSRFCookieName', $app_config_content);
        $app_config_content = str_replace('public $CSRFExpire', '//public $CSRFExpire', $app_config_content);
        $app_config_content = str_replace('public $CSRFRegenerate', '//public $CSRFRegenerate', $app_config_content);
        $app_config_content = str_replace('public $CSRFRedirect', '//public $CSRFRedirect', $app_config_content);
        $app_config_content = str_replace('public $CSRFSameSite', '//public $CSRFSameSite', $app_config_content);


        //update set_supported_languages
        $pattern = '/(private function set_supported_languages\(\)\s*{)/';
        $line_to_add = '$1
        if(count($this->supportedLocales)) return ;';
        $app_config_content = preg_replace($pattern, $line_to_add, $app_config_content);


        // Remove the function by replacing it with an empty string
        $pattern = '/private function set_cookie_domain\(\)\s*{[^{}]*({[^{}]*}[^{}]*)*}/s';
        $app_config_content = preg_replace($pattern, '', $app_config_content);

        // Set timezone as utc
        $pattern = '/public\s+\$appTimezone\s*=\s*\'[^\']*\';/';
        $replacement = "public \$appTimezone = 'UTC';";
        $app_config_content = preg_replace($pattern, $replacement, $app_config_content);


        file_put_contents($app_config_file, $app_config_content);
    }


    function update_session_config() {

        $session_config_file = 'app/Config/Session.php';
        $session_config_content = file_get_contents($session_config_file);

        //Comment out the lockRetryInterval & lockMaxRetries if already exists.
        $session_config_content = str_replace('public $lockRetryInterval', '//public $lockRetryInterval', $session_config_content);
        $session_config_content = str_replace('public $lockMaxRetries', '//public $lockMaxRetries', $session_config_content);

        // Find the last closing } and add the new lines before it
        $new_lines = "\n\n\n    public \$lockRetryInterval = 100_000; \n\n\n    public \$lockMaxRetries = 300;\n\n";
        $session_config_content = preg_replace('/\n\}(?!.*\n\})/', "$new_lines}", $session_config_content);

        file_put_contents($session_config_file, $session_config_content);
    }

    function add_invoice_settings($db, $dbprefix) {
        $settings_table = $dbprefix . "settings";
        $setting_info = $db->query("SELECT * FROM $settings_table WHERE `setting_name` = 'invoice_number_format' AND `type` = 'app' AND `deleted` = 0");
        if ($setting_info->getNumRows() == 0) {
            $db->query("INSERT INTO $settings_table (`setting_name`, `setting_value`, `type`, `deleted`) VALUES ('invoice_number_format', '{SERIAL}', 'app', 0)");
        } else if ($setting_info->getNumRows() > 0 && !$setting_info->getRow()->setting_value) {
            $db->query("UPDATE $settings_table SET `setting_value` = '{SERIAL}' WHERE `setting_name` = 'invoice_number_format' AND `type` = 'app' AND `deleted` = 0");
        }
    }

    update_app_config();
    update_session_config();
    add_invoice_settings($db, $dbprefix);

    helper("filesystem");
    delete_files("app/ThirdParty/Imap/ddeboer-imap", true);
} catch (\Exception $exc) {
    log_message("error", $exc->getTraceAsString());
    echo $exc->getTraceAsString();
}
